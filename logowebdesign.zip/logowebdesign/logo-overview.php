<!DOCTYPE html>

<html lang="en">

    <head>

    <title>Logos Web Design | Logo</title>   

    <?php include("inc/header.php"); ?>

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo$main_url;?>img/banner_logo.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-12">
                                <div class="row d-none">
                                     <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-american"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-austin"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-cudjoe"></i>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                Increase your brand value
                                                <span>with logos that stand out.</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12">
                                <div class="card">
                                    <div class="card-header" data-aos="fade-up">
                                        <h2>70% DISCOUNT</h2>
                                    </div>
                                    <div class="card-body">
                                        <h3>
                                            Let’s start your project,
                                            <strong>Drop us your details!</strong>
                                        </h3>
                                            <div data-form-type="signup_form">
                                                <form method="post" enctype="multipart/form-data" action="javascript:void(0)" class="leadForm">
                                                    <!--hidden required values-->
                                                    <input type="hidden" id="formType" name="formType">
                                                    <input type="hidden" id="referer" name="referer">
                                                    <div class="form-group">
                                                        <label for="name" class="d-none">Name</label>
                                                        <input type="text" name="name" required  class="form-control btn-rounded" id="name" placeholder="Your Name">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email" class="d-none">email</label>
                                                        <input type="email" name="email" required class="form-control btn-rounded" id="email" placeholder="Email Address">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="number" class="d-none">phone</label>
                                                        <input type="tel" name="phone" required class="form-control btn-rounded" maxlength="12" id="phone" placeholder="Phone Number">
                                                    </div>
                                                    <div id="formResult"></div>
                                                    <div class="form-group">
                                                        <button name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
                                                    </div>
                                                </form>
                                            </div>
                                            <p>*Our Design Consultant will call you to confirm your package</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">logo design</a>
                        </li>
                        <li>
                            <a href="#2a" data-toggle="tab">logo package</a>
                        </li>
                        <li>
                            <a href="#3a" data-toggle="tab">logo process</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <section class="pg whyUs" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 bg-grey">
                                            <h2 class="title">why us?</h2>
                                            <div class="why-content">
                                                <div class="col-md-6">
                                                    <img src="<?php echo$main_url;?>img/whyUs.jpg" alt="whyUs">
                                                </div>
                                                <div class="col-md-6">
                                                    <h3>Our solutions are creatively designed and skilfully executed.                                                    </h3>
                                                    <p>
                                                        With a professional team like Grafik Agency your branding is sure to escalate. Our designers are experts at understanding and integrating the consumer mindset in your logo to blend the creativity with business. We take care of it all so you don't have to.
                                                    </p>
                                                    <ul class="whyList">
                                                        <li>
                                                            <i class="sprite sprite-y1"></i>
                                                            <h6>Quick Turnaround Time</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y2 mt-2"></i>
                                                            <h6>Cost-effective Designers</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y3"></i>
                                                            <h6>Award-winning Desgin</h6>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                
                            </section>
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">Abstract Logos</li>
                                                <li class="tab-link" data-tab="tab-3">Typographic Logos</li>
                                                <li class="tab-link" data-tab="tab-4">3D Logos</li>
                                                <li class="tab-link" data-tab="tab-5">Animated Logos</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li><a href="<?php echo$main_url;?>img/lp1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp1.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp2.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp3.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp4.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp5.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp6.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp7.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp8.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp9.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/lp10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/lp10.jpg" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-white-outline active chat btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-down">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Simpler Solutions. Quicker Results.</h2>
                                                    <p>Our Logos are designed in accordance to your industry trends</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Abstract Logo</h3>
                                                        <p>
                                                            Say more with less. Not everyone likes to go for a detailed approach, sometimes due to personal preferences while sometimes due to industry requirements. Regardless of the reason behind your choice, we aim to deliver a hundred and ten percent! Abstract logos give off an air of confidence, simplicity, and professionalism. We design each logo with the essence of your business intact in each element. 
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Professional Abstract Logo designers</li>
                                                            <li>Unlimited revisions</li>
                                                            <li>Quick turnover time</li>
                                                            <li>100% satisfaction guaranteed</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/AL.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Typographic Logos</h3>
                                                        <p>
                                                            A logo is more than your company name arranged in a pretty manner. It is about setting a tone & creating a perception in your consumers’ minds. Most of the startups don’t know where to start with their branding, this is what keeps them behind their competitors. Grafik Agency gives you the required push to reach your maximum potential in the least time period. Quick and efficient turnover is what every investor seeks in investment & we are here to get that for you.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Professional Typographic Logo designers</li>
                                                            <li>Unlimited revisions</li>
                                                            <li>Quick turnover time</li>
                                                            <li>100% satisfaction guaranteed</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/TL.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Animated Logos</h3>
                                                        <p>
                                                            Animated logos are a great way to communicate with your audience in a fun
                                                            and engaging way. You can deliver more in less time with a dynamic logo that
                                                            animates your intended message in an interactive way. This is more suitable 
                                                            for brands targeting younger and more socially active consumers, as they create an impressive and long-lasting look on some tech-savvy viewers. A successful logo is a seamless blend of business and art which is not quite easy to reach. 
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Professional Animated Logo designers</li>
                                                            <li>Unlimited revisions</li>
                                                            <li>Quick turnover time</li>
                                                            <li>100% satisfaction guaranteed</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/ANL.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>3D Logos</h3>
                                                        <p>
                                                            Keep it simple yet impressive. Many clients worry that too much detail or
                                                            designing elements in their logo would be too much while a simple logo would
                                                            be too dull and give a lazy impression. We suggest 3D logos as the ideal solution to these anxieties. A 3D logo keeps it simple while still puts a little depth and detail into the overall design. This makes 3D logos one of their kind and keeps your branding fresh and lively.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Professional 3D Logo designers</li>
                                                            <li>Unlimited revisions</li>
                                                            <li>Quick turnover time</li>
                                                            <li>100% satisfaction guaranteed</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/3D.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">Looking for a creative logo </h2>
                                            <p>That converses your brand personality? We create custom logo designs that raise appeal and brand.  </p>
                                            <ul class="creativity">
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/revision.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/revision.png" alt="quote">
                                                        </i>
                                                        <p>Unlimited Revisions</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/ownership.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/ownership.png" alt="quote">
                                                        </i>
                                                        <p>100% Ownership Rights</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/moneyBack.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/moneyBack.png" alt="quote">
                                                        </i>
                                                        <p>100% Money Back Guarantee</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pg packages" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">REASONABLE DESIGN PACKAGES</h2>
                                            <p>We have reasonably tailored packages suitable for your requirements and budget so we have something for everyone.</p>
                                            <div class="packageList tab-packageSlider owl-carousel owl-theme">
                                                <div>                                                                                                    
                                                <div data-package-box class="pricing-box  ">
                                                    <div class="productSku" style="display: none;">LOGO_STARTUP_LOGO    </div>
                                                    <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Startup</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>29</h2>
                                                <h3><span>£96.67</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>3 Design Concepts</li>
                                                <li>2 Revisions</li>
                                                <li>Dedicated Designer</li>
                                                <li>Turnaround Time 24 - 48 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_STARTUP_LOGO"
                                                  data-promotion-id="0"
                                                  data-price="29"
                                                  data-price-text="£29"
                                                  data-title="Logo Startup"
                                                  data-package-id="749">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                              
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">LOGO_LOGO_BASIC </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Basic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>16</h2>
                                                <h3><span>£32</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>6 Design Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>3 Revisions</li>
                                                <li>2 Dedicated Designers</li>
                                                <li>Turnaround Time 24 - 48 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>                                           
                                         </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_BASIC"
                                                  data-promotion-id="0"
                                                  data-price="16"
                                                  data-price-text="£16"
                                                  data-title="Logo Basic"
                                                  data-package-id="750">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                    
                        <div>
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">LOGO_LOGO_PLUS    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Classic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>46</h2>
                                                <h3><span>£92</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>8 Design Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>Unlimited Revisions</li>
                                                <li>3 Dedicated Designers</li>
                                                <li>Turnaround Time 24 - 48 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>  
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_PLUS"
                                                  data-promotion-id="0"
                                                  data-price="46"
                                                  data-price-text="£46"
                                                  data-title="Logo Classic"
                                                  data-package-id="751">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                        
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">LOGO_LOGO_PRIME    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Elite Package</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>76</h2>
                                                <h3><span>£152</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>Unlimited Logo Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>Unlimited Revisions</li>
                                                <li>4 Dedicated Designers</li>
                                                <li>Turnaround time 48 - 72 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_PRIME"
                                                  data-promotion-id="0"
                                                  data-price="76"
                                                  data-price-text="£76"
                                                  data-title="Logo Elite Package"
                                                  data-package-id="752">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">LOGO_LOGO_ADVANCE</div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Advance</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>169</h2>
                                                <h3><span>£563</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>2 Unique Illustration </li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>2 Dedicated Designers</li>
                                                    <li>Turnaround time 48 - 72 hours</li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_ADVANCE"
                                                  data-promotion-id="0"
                                                  data-price="169"
                                                  data-price-text="£169"
                                                  data-title="Logo Advance"
                                                  data-package-id="753">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                    
                        <div>
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">LOGO_LOGO_ULTIMATE    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Ultimate</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>209</h2>
                                                <h3><span>£696</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Unique Mascot Concept</li>
                                                <li>3 Dedicated Designers</li>
                                                <li>Unlimited Revisions</li>
                                                <li>Turnaround time 48 - 72 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_ULTIMATE"
                                                  data-promotion-id="0"
                                                  data-price="209"
                                                  data-price-text="£209"
                                                  data-title="Logo Ultimate"
                                                  data-package-id="754">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                    
                    </div>
                                            <h4>Key Features</h4>
                                            <ul class="list-center satisfaction text-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sG"></i>
                                                    <p>100% Satisfaction Guaranteed</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-cS"></i>
                                                    <p>24 X 7 Customer Support</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-oR"></i>
                                                    <p>100% Ownership Rights</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-mBG"></i>
                                                    <p>Money Back Guarantee</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-iSD"></i>
                                                    <p>Industry Specific Designers</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                            <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                            <ul class="list-center">
                                                <li class="first">
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>Initial <br>Designing</h4>
                                                    <p>Within days you recieve intitial files of your fully customized logo.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR"></i>
                                                    <h4>Design <br>Revisions</h4>
                                                    <p>In case of any dissatisfaction or additions in your initial designs, we are here for unlimited revisions.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-fD"></i>
                                                    <h4>Final <br>Designs</h4>
                                                    <p>After unlimited revisions until complete satisfaction, you will recieve the final designs.</p>
                                                </li>
                                                <li class="last">
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Project <br>Delivery</h4>
                                                    <p>We stay with you even after the project is done and value your feedback and reviews.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="4a">
                            <div class="pg secretDelievery">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li>
                                                    <h4>How do I place an order?</h4>
                                                    <p>You can either place an online order simply by selecting a logo package of your choice or you can live chat or call one of our professional customer care assistants for consultation or any other questions you may have.</p>
                                                </li>
                                                <li>
                                                    <h4>How can I pay for my Logo order?</h4>
                                                    <p>You can either pay through credit cards, PayPal, Wire Transfer or Bank Cheques.</p>
                                                </li>
                                                <li>
                                                    <h4>How long does it take to have the initial designs?</h4>
                                                    <p>As soon as you place and confirm your order, our experts start working on your project and it usually takes between 24 to 48 hours to deliver your initial designs.</p>
                                                </li>
                                                <li>
                                                    <h4>What if I don't like the initial designs?</h4>
                                                    <p>In such case, you can either opt for a free revision where you get unlimited free revisions until you're completely satisfied or a refund. Review our refund and money back guarantee section for details. </p>
                                                </li>
                                                <li>
                                                    <h4>Does Grafik Agency provide revamp service?</h4>
                                                    <p>Absolutely! We have special packages for customers looking for redesigning of their current work.</p>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
</html>   