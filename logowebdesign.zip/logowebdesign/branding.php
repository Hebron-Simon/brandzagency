<!DOCTYPE html>

<html lang="en">

    <head>

    <title>Logos Web Design | Branding</title>   

    <?php include("inc/header.php"); ?>

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo$main_url;?>img/banner_print.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-12">
                                <div class="row d-none">
                                    <div class="col">
                                        <i class="sprite_1 sprite-Lban1" data-aos="fade-up"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban2"></i>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <i class="sprite_1 sprite-Lban3"></i>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                Targeted Branding
                                                <span>at Affordable Prices</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12">
                                <div class="card" data-aos="fade-up">
                                    <div class="card-header">
                                        <h2>70% DISCOUNT</h2>
                                    </div>
                                    <div class="card-body">
                                        <h3>
                                            Let’s start your project,
                                            <strong>Drop us your details!</strong>
                                        </h3>
                                        <div data-form-type="signup_form">
    <form method="post" enctype="multipart/form-data" action="javascript:void(0)" class="leadForm">
        <!--hidden required values-->
        <input type="hidden" id="formType" name="formType">
        <input type="hidden" id="referer" name="referer">
        <div class="form-group">
            <label for="name" class="d-none">Name</label>
            <input type="text" name="name" required  class="form-control btn-rounded" id="name" placeholder="Your Name">
        </div>
        <div class="form-group">
            <label for="email" class="d-none">email</label>
            <input type="email" name="email" required class="form-control btn-rounded" id="email" placeholder="Email Address">
        </div>
        <div class="form-group">
            <label for="number" class="d-none">phone</label>
            <input type="tel" name="phone" required class="form-control btn-rounded" maxlength="12" id="phone" placeholder="Phone Number">
        </div>
        <div id="formResult"></div>
        <div class="form-group">
            <button name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
        </div>
    </form>
</div>                                        <p>
                                            *Our Design Consultant will call you to confirm your package
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">Brand Design</a>
                        </li>
                        <li>
                            <a  href="#2a" data-toggle="tab">packages</a>
                        </li>
                        <li>
                            <a  href="#3a" data-toggle="tab">process</a>
                        </li>
                        <li>
                            <a href="#4a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <section class="pg whyUs" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 bg-grey">
                                            <h2 class="title">why us?</h2>
                                            <div class="why-content">
                                                <div class="col-md-6">
                                                    <img src="<?php echo$main_url;?>img/whyUs.jpg" alt="whyUs">
                                                </div>
                                                <div class="col-md-6">
                                                    <h3>We work with industry-trained branding experts to keep the essence of your business upfront.</h3>
                                                    <p>
                                                        With a professional approach in branding strategies, our strategists start with a calculated and researched start to move in the right direction from step one. Our tried and tested methods of branding are sure to escalate and refresh your brand image and increase your sales.
                                                    </p>
                                                    <ul class="whyList">
                                                        <li>
                                                            <i class="sprite_1 sprite-design"></i>
                                                            <h6>Immaculate Design</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite_1 sprite-winning"></i>
                                                            <h6>Award Winning Designers</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y3"></i>
                                                            <h6>Guaranteed Satisfaction</h6>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                
                            </section>
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">Brochure Design</li>
                                                <li class="tab-link" data-tab="tab-3">Print Ads</li>
                                                <li class="tab-link" data-tab="tab-4">Post Cards</li>
                                                <li class="tab-link" data-tab="tab-5">Book Cover</li>
                                                <li class="tab-link" data-tab="tab-5">Folder Design</li>
                                                <li class="tab-link" data-tab="tab-5">Billboards</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li class="first"><a href="<?php echo$main_url;?>img/pp1.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp2.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp3.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp4.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp5.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp6.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp7.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp8.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/pp9.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                <li class="last"><a href="<?php echo$main_url;?>img/pp10.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-6">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-7">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/pp1.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp2.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp3.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp4.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp5.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp6.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp7.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp8.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp9.png" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/pp10.png" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>                                        
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                                <li><a href="#" class="btn btn-rounded btn-white-outline active chat btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg bg-grey" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="text-center">
                                                <h2 class="title">Only the Best Branding Services</h2>
                                                <p>We don't compromise on quality and keep the essence of your business intact in branding</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="large-img">
                                    <div class="image-50 ml-auto">
                                        <img src="<?php echo$main_url;?>img/printing.png" alt="printing">
                                    </div>
                                    <div class="container">
                                        <div class="col-lg-6 col-12">
                                            <ul class="tick-list">
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Save Money & Time</h4>
                                                        <p>
                                                            With both quality design and digital branding services under one roof, you won't only be saving time but also money as we take care of the entire process from beginning to end.
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>More Creativity</h4>
                                                        <p>
                                                            Double the amount of resources mean double the amount of creativity. Our extended team of skilled designers and brand experts offer you more creativity in less time.                                                       
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Dedicated Account Managers</h4>
                                                        <p>
                                                            We make sure that the entire process runs smoothly within a short span of time by removing any confusions in the ordering process. Each client gets a dedicated account manager.                                                        
                                                        </p>
                                                    </div>
                                                </li>
                                                <li>
                                                        <i class="sprite_1 sprite-tick"></i>
                                                    <div class="listDesc">
                                                        <h4>Money Back Guarantee*</h4>
                                                        <p>
                                                            We offer unlimited revisions before finalizing to reduce any chances for a refund or unsatisfied customer. But in any case you're still not satisfied, we give money back guarantee.
                                                        </p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">Looking for a quality printing </h2>
                                            <p>That converses your brand personality? We offer print designs that raise appeal and brand.  </p>
                                            <ul class="creativity">
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/revision.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/revision.png" alt="quote">
                                                        </i>
                                                        <p>Unlimited Revisions</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/ownership.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/ownership.png" alt="quote">
                                                        </i>
                                                        <p>100% Ownership Rights</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/moneyBack.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/moneyBack.png" alt="quote">
                                                        </i>
                                                        <p>100% Money Back Guarantee</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pg packages" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">REASONABLE DESIGN PACKAGES</h2>
                                            <p>We have reasonably tailored packages suitable for your requirements and budget so we have something for everyone.</p>
                                            <div class="packageList tab-packageSlider owl-carousel owl-theme">                                                                                  
                                                <div>
                                                    <div data-package-box class="pricing-box  ">
                                                        <div class="productSku" style="display: none;">BRANDING_STATIONNARY    </div>
                                                        <div>
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <p class="bestSeller">Stationery</p>
<!--                                                                <h4>--><?//= $short_description ?><!--</h4>-->
                                                                <div class="price">
                                                                    <h2><span>£</span>79</h2>
                                                                    <h3><span>£263.33</span></h3>
                                                                </div>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="scroll" data-package-scroll>
                                                                  <ul>
                                                                        <li>1 Business Card Design</li>
                                                                        <li>1 Letterhead Design</li>
                                                                        <li>1 Envelope Design</li>
                                                                        <li>Dedicated Designer</li>
                                                                        <li>3 Design Revisions</li>
                                                                        <li>Turnaround Time 24 - 48 Hours</li>
                                                                        <li>Features:</li>
                                                                        <li>100% Satisfaction Guaranteed</li>
                                                                        <li>100% Ownership rights</li>
                                                                        <li>100% Unique Design Guarantee</li>
                                                                        <li>100% Money Back Guarantee</li>
                                                                        <li>All Final File Formats</li>
                                                                        <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                        </ul>                                            
                                                                    </div>
                                                            </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_STATIONNARY"
                                                  data-promotion-id="0"
                                                  data-price="79"
                                                  data-price-text="£79"
                                                  data-title="Stationery"
                                                  data-package-id="767">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                        
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">BRANDING_BROCHURE_FLYER    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Brochure/Flyer</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>139</h2>
                                                <h3><span>£463</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>2 Design Concepts (Trifold / Bi-fold)</li>
                                                <li>Dedicated Designer</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Unlimited Revisions</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_BROCHURE_FLYER"
                                                  data-promotion-id="0"
                                                  data-price="139"
                                                  data-price-text="£139"
                                                  data-title="Brochure/Flyer"
                                                  data-package-id="768">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                        
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_POSTER_DESIGN    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Poster Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>139</h2>
                                                <h3><span>£463</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Unique Design</li>
                                                <li>3 Design Concepts</li>
                                                <li>Dedicated Designer</li>
                                                <li>2 Design Revisions</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_POSTER_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="139"
                                                  data-price-text="£139"
                                                  data-title="Poster Design"
                                                  data-package-id="769">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                        
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">BRANDING_T_SHIRT_DESIGN    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">T-Shirt Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>179</h2>
                                                <h3><span>£596</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>1 Unique Design</li>
                                                    <li>6 Design Concepts</li>
                                                    <li>Front and Back Business Logo Placement</li>
                                                    <li>Dedicated Designer</li>
                                                    <li>4 Design Revisions</li>
                                                    <li>Turnaround Time - 48 - 72 Hours</li>
                                                    <li>Features:</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Ownership rights</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_T_SHIRT_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="179"
                                                  data-price-text="£179"
                                                  data-title="T-Shirt Design"
                                                  data-package-id="770">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                        
                        </div>                                                                                                    
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_MAGAZINE_DESIGN</div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Magazine Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>160</h2>
                                                <h3><span>£533</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                        <li>3 Cover Design Concepts</li>
                                                        <li>1 Concept (Inner Pages Design)</li>
                                                        <li>Dedicated Designer</li>
                                                        <li>Unlimited Revision</li>
                                                        <li>Turnaround Time - 48 - 72 Hours</li>                                               
                                                        <li>Features:</li>
                                                        <li>100% Satisfaction Guaranteed</li>
                                                        <li>100% Ownership rights</li>
                                                        <li>100% Unique Design Guarantee</li>
                                                        <li>100% Money Back Guarantee</li>
                                                        <li>All Final File Formats</li>
                                                        <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_MAGAZINE_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="160"
                                                  data-price-text="£160"
                                                  data-title="Magazine Design"
                                                  data-package-id="771">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                        
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_LANDING_PAGES    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Landing Pages</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>149</h2>
                                                <h3><span>£496</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                                    <ul>
                                                        <li>1 Custom Design Concept</li>
                                                        <li>Mobile Responsive Design </li>
                                                        <li>SEO Optimized Landing Page</li>
                                                        <li>Dedicated Account Manager</li>
                                                        <li>Unlimited Revisions</li>
                                                        <li>Turnaround Time - 48 - 72 Hours</li>
                                                        <li>Features:</li>
                                                        <li>100% Satisfaction Guaranteed</li>
                                                        <li>100% Ownership rights</li>
                                                        <li>100% Unique Design Guarantee</li>
                                                        <li>100% Money Back Guarantee</li>
                                                        <li>All Final File Formats</li>
                                                        <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                           
                                                         </div>
                                                                </div>
                                                                <div class="card-footer">
                                                                    <ul class="list-center">
                                                                        <li>
                                                                          <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_LANDING_PAGES"
                                                                          data-promotion-id="0"
                                                                          data-price="149"
                                                                          data-price-text="£149"
                                                                          data-title="Landing Pages"
                                                                          data-package-id="772">Order now</button>
                                                                        </li>
                                                                        <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                        <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                        <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>                                        
                                                </div>                                                                                                                                                                  
                                            </div>
                                            <h4>Key Features</h4>
                                            <ul class="list-center satisfaction text-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sG"></i>
                                                    <p>100% Satisfaction Guaranteed</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-cS"></i>
                                                    <p>24 X 7 Customer Support</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-oR"></i>
                                                    <p>100% Ownership Rights</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-mBG"></i>
                                                    <p>Money Back Guarantee</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-iSD"></i>
                                                    <p>Industry Specific Designers</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                            <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>Strategizing</h4>
                                                    <p>We brainstorm to understand the ups and downs of your industry and consumer mindsets.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-fD"></i>
                                                    <h4>Execution </h4>
                                                    <p>Our experts walk with you throughout the process to make the strategy work</p>
                                                </li>
                                                <!-- <li>
                                                    <i class="sprite_1 sprite-dR"></i>
                                                    <h4>Unlimited <br>Revision</h4>
                                                    <p>Before we send your design to the printers, we make sure everything is up to your satisfaction.</p>
                                                </li> -->
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Faster Turnaround</h4>
                                                    <p>Our branding strategies have the fastest turnaround time with ROI guaranteed!</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="4a">
                        <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li>
                                                    <h4>Why do I need branding services?</h4>
                                                    <p>Branding services help you convert and expand your audience. It is all about digital and physical upfront of your business and how you represent yourself so it is very important to invest in branding services for better scalability. </p>
                                                </li>
                                                <li>
                                                    <h4>What type of results should I expect?</h4>
                                                    <p>The key performance indicators we look at for branding are new subscribers, open-rate, click-through-rates, and conversions. We will measure and evaluate these metrics monthly to optimize for conversions.</p>
                                                </li>
                                                <li>
                                                    <h4>What is the turnaround time? </h4>
                                                    <p>Printed materials can be delivered to you in 2-3 business days. Whereas digital branding like SEO, PPC and online advertisement are part of an ongoing process.</p>
                                                </li>
                                                <li>
                                                    <h4>What if I'm not satisfied with the end results?</h4>
                                                    <p>That is highly unlikely because we make sure everything is to your liking before finalizing our delivery process but if you're facing such a problem then review our refund and money back guarantee terms and conditions.</p>
                                                </li>    
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
</main>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
</html>   