<section class="pg" data-aos="fade-up">
                <div class="simplerSol">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="text-center">
                                    <h2 class="title">LEADING THE INDUSTRY For OVER A DECADE</h2>
                                    <p>Our designers are trained to serve the best interests of our clients and give them a brand identity to be remembered for decades</p>
                                </div>
                            </div>
                        </div>
                        <div id="serviceSlider">
                            <div class="ss-slider">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3>Logo design</h3>
                                        <p>
                                            Our designers work in coordination with our expeirnced marketers who analyze and estimate your branding by researching and brainstorming the perfect logo that fulfills the required trends of your relevant market and grabs maximum attention of the targeted audience. This is what keeps us above average.
                                        </p>
                                        <ul class="arrow-list">
                                            <li>100% Satisfaction Guaranteed</li>
                                            <li>Professional Designers</li>
                                            <li>Unlimited Revisions</li>
                                            <li>Affordable and Reliable</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <img src="<?php echo $main_url ; ?>img/LD.png" alt="ss">
                                    </div>
                                </div>
                            </div>
                            <div class="ss-slider">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3>Branding Services</h3>
                                        <p>Our branding services revolve around the elements of aesthetics, functionality, and customer retention. A good branding strategy needs experienced branding experts to make it work perfectly and unlock the maximum potential of your business. For complete branding of your business, we provide everything from corporate stationery, brochures to high quality branding solutions that take your business to a whole new level. Don’t compromise when it comes to the branding of your business. </p>
                                        <ul class="arrow-list">
                                            <li>100% Satisfaction Guranteed</li>
                                            <li>Branding Experts</li>
                                            <li>Result-driven Strategies</li>
                                            <li>Affordable and Reliable</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <img src="<?php echo $main_url ; ?>img/PS.png" alt="ss">
                                    </div>
                                </div>
                            </div>
                            <div class="ss-slider">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3>SEO Services</h3>
                                        <p>
                                            Search Engine Optimization is the leading game of most of the digital competitors. Eveyone wants to be at the top but do you have what it takes to be on the top? Don't worry because Logos Web Design has what it takes to scale our clients all the way to the top and beyond. Sign up for our impeccable SEO Services and get all the value-added benefits that only industry's best is serving.
                                        </p>
                                        <ul class="arrow-list">
                                            <li>Quick turnover</li>
                                            <li>Keyword research</li>
                                            <li>Performance Analysis and Matrices</li>
                                            <li>100% Satisfaction Guaranteed</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <img src="<?php echo $main_url ; ?>img/SEO.png" alt="ss">
                                    </div>
                                </div>
                            </div>
                            <div class="ss-slider">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3>Video Animation</h3>
                                        <p>
                                            According to recent studies, most of the content shared on social media platforms is video-based. Chances are, your users are more likely to share and view video content as compared to any text or image-based content. Spark up your brand with livelier and fresher elements of Logos Web Design’s video animation services at amazingly affordable prices. Our team of illustrators, scriptwriters and animators deliver more than what is required to our position as the leading animation service provider.
                                        </p>
                                        <ul class="arrow-list">
                                            <li>Various styles of animation</li>
                                            <li>Umlimitd Revisions</li>
                                            <li>Quick turnover time</li>
                                            <li>100% Satisfaction Guaranteed</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <img src="<?php echo $main_url ; ?>img/VD.png" alt="ss">
                                    </div>
                                </div>
                            </div>
                            <div class="ss-slider">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h3>App Design & Development</h3>
                                        <p>
                                            In this mobile-driven world, it is very imprtant to have a decent mobile app for your business marketing and operations. But an app is only as good as its UI/UX experience, if an app is not optimized acording to its user base then it is not  gonna do much for you or your marketing strategies. Our app developers are among the industry's top, specializing in iOS and Andriod app design and development. With Logos Web Design you get much more than you go for.
                                        </p>
                                        <ul class="arrow-list">
                                            <li>100% Satisfaction Guaranteed</li>
                                            <li>Cross platform performance</li>
                                            <li>UI/UX friendly</li>
                                            <li>Affordable and Reliable</li>
                                        </ul>
                                    </div>
                                    <div class="col-md-6">
                                        <img src="<?php echo $main_url ; ?>img/ADD.png" alt="ss">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </section>