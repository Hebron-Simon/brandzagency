<section>
            <div class="pg packages">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="title">REASONABLE DESIGN PACKAGES</h2>
                            <p>We have reasonably tailored packages suitable for your requirements and budget so we have something for everyone.</p>
                            <div id="exTab2">
                                <ul class="nav nav-tabs tab-pill" role="tablist">
                                    <li class="first active">
                                        <a class="active show" data-toggle="tab" href="#tabLogo" role="tab" aria-expanded="true">Logo</a>
                                    </li>

                                    <li class="">
                                        <a data-toggle="tab" href="#tabWebCorporate" role="tab">Website Corporate</a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" href="#tabWebEcom" role="tab">Website E-commerce</a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" href="#tabWebCombo" role="tab">Website Combo</a>
                                    </li>
                                    <li class="">
                                        <a data-toggle="tab" href="#tabBranding" role="tab">Branding</a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" href="#tabAnimation" role="tab">Animation</a>
                                    </li>
                                </ul>
                                <div class="tab-content clearfix">
                                    <div id="tabLogo" class="tab-pane fade active show in" role="tabpanel" aria-labelledby="tabLogo">
                                        <div class="packageList tab-packageSlider owl-carousel owl-theme">
                                            <div class="item">
                                                <div data-package-box class="pricing-box  ">
                                                    <div class="productSku" style="display: none;">LOGO_STARTUP_LOGO    </div>
                                                    <div>
                                                        <div class="card">
                                                        <div class="card-header">
                                                        <p class="bestSeller">Logo Startup</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                                <div class="price">
                                                <h2><span>£</span>29</h2>
                                                <h3><span>£96.67</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                            <li>3 Design Concepts</li>
                                            <li>2 Revisions</li>
                                            <li>Dedicated Designer</li>
                                            <li>Turnaround Time 24 - 48 hours</li>
                                            <li>Dedicated Account Manager</li>
                                            <li>100% Ownership Rights</li>
                                            <li>100% Satisfaction Guaranteed</li>
                                            <li>100% Unique Design Guarantee</li>
                                            <li>100% Money Back Guarantee</li>
                                            <li>All Final File Formats</li>
                                            <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>                                           
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_STARTUP_LOGO"
                                                  data-promotion-id="0"
                                                  data-price="29"
                                                  data-price-text="£29"
                                                  data-title="Logo Startup"
                                                  data-package-id="749">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone_link;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="item">
                        <div data-package-box class="pricing-box  ">
                            <div class="productSku" style="display: none;">LOGO_LOGO_BASIC  </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Basic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>16</h2>
                                                <h3><span>£32</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>6 Design Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>3 Revisions</li>
                                                <li>2 Dedicated Designers</li>
                                                <li>Turnaround Time 24 - 48 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_BASIC"
                                                  data-promotion-id="0"
                                                  data-price="16"
                                                  data-price-text="£16"
                                                  data-title="Logo Basic"
                                                  data-package-id="750">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">LOGO_LOGO_PLUS    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Classic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>46</h2>
                                                <h3><span>£92</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>8 Design Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>Unlimited Revisions</li>
                                                <li>3 Dedicated Designers</li>
                                                <li>Turnaround Time 24 - 48 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>  
                                            </ul>
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_PLUS"
                                                  data-promotion-id="0"
                                                  data-price="46"
                                                  data-price-text="£46"
                                                  data-title="Logo Classic"
                                                  data-package-id="751">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">LOGO_LOGO_PRIME    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Elite Package</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>76</h2>
                                                <h3><span>£152</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>Unlimited Logo Concepts</li>
                                                <li>Free Icon Design</li>
                                                <li>Unlimited Revisions</li>
                                                <li>4 Dedicated Designers</li>
                                                <li>Turnaround time 48 - 72 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>
                                        </div>
                                    </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_PRIME"
                                                  data-promotion-id="0"
                                                  data-price="76"
                                                  data-price-text="£76"
                                                  data-title="Logo Elite Package"
                                                  data-package-id="752">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <div class="item">
                                <div data-package-box class="pricing-box  ">
                                    <div class="productSku" style="display: none;">LOGO_LOGO_ADVANCE  </div>
                                    <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Advance</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>169</h2>
                                                <h3><span>£563</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>2 Unique Illustration </li>
                                                <li>Unlimited Revisions</li>
                                                <li>2 Dedicated Designers</li>
                                                <li>Turnaround time 48 - 72 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_ADVANCE"
                                                  data-promotion-id="0"
                                                  data-price="169"
                                                  data-price-text="£169"
                                                  data-title="Logo Advance"
                                                  data-package-id="753">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">LOGO_LOGO_ULTIMATE</div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Logo Ultimate</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>209</h2>
                                                <h3><span>£696</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Unique Mascot Concept</li>
                                                <li>3 Dedicated Designers</li>
                                                <li>Unlimited Revisions</li>
                                                <li>Turnaround time 48 - 72 hours</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                </ul> 
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="LOGO_LOGO_ULTIMATE"
                                                  data-promotion-id="0"
                                                  data-price="209"
                                                  data-price-text="£209"
                                                  data-title="Logo Ultimate"
                                                  data-package-id="754">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                                                                
                    </div>
                </div>
                <div id="tabBranding" class="tab-pane fade" role="tabpanel" aria-labelledby="tabBranding">
                    <div class="packageList tab-packageSlider owl-carousel owl-theme">
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_STATIONNARY    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Stationery</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>79</h2>
                                                <h3><span>£263.33</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Business Card Design</li>
                                                <li>1 Letterhead Design</li>
                                                <li>1 Envelope Design</li>
                                                <li>Dedicated Designer</li>
                                                <li>3 Design Revisions</li>
                                                <li>Turnaround Time 24 - 48 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_STATIONNARY"
                                                  data-promotion-id="0"
                                                  data-price="79"
                                                  data-price-text="£79"
                                                  data-title="Stationery"
                                                  data-package-id="767">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">BRANDING_BROCHURE_FLYER    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Brochure/Flyer</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>139</h2>
                                                <h3><span>£463</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>2 Design Concepts (Trifold / Bi-fold)</li>
                                                    <li>Dedicated Designer</li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>Turnaround Time - 48 - 72 Hours</li>
                                                    <li>Features:</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Ownership rights</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_BROCHURE_FLYER"
                                                  data-promotion-id="0"
                                                  data-price="139"
                                                  data-price-text="£139"
                                                  data-title="Brochure/Flyer"
                                                  data-package-id="768">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_POSTER_DESIGN</div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Poster Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>139</h2>
                                                <h3><span>£463</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Unique Design</li>
                                                <li>3 Design Concepts</li>
                                                <li>Dedicated Designer</li>
                                                <li>2 Design Revisions</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>
                                        </div>
                                    </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_POSTER_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="139"
                                                  data-price-text="£139"
                                                  data-title="Poster Design"
                                                  data-package-id="769">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">BRANDING_T_SHIRT_DESIGN    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">T-Shirt Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>179</h2>
                                                <h3><span>£596</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Unique Design</li>
                                                <li>6 Design Concepts</li>
                                                <li>Front and Back Business Logo Placement</li>
                                                <li>Dedicated Designer</li>
                                                <li>4 Design Revisions</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_T_SHIRT_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="179"
                                                  data-price-text="£179"
                                                  data-title="T-Shirt Design"
                                                  data-package-id="770">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>                                                                                                                        
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_MAGAZINE_DESIGN    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Magazine Design</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>160</h2>
                                                <h3><span>£533</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>3 Cover Design Concepts</li>
                                                <li>1 Concept (Inner Pages Design)</li>
                                                <li>Dedicated Designer</li>
                                                <li>Unlimited Revision</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                            </ul>                                            
                                        </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_MAGAZINE_DESIGN"
                                                  data-promotion-id="0"
                                                  data-price="160"
                                                  data-price-text="£160"
                                                  data-title="Magazine Design"
                                                  data-package-id="771">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">BRANDING_LANDING_PAGES    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Landing Pages</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>149</h2>
                                                <h3><span>£496</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>1 Custom Design Concept</li>
                                                <li>Mobile Responsive Design </li>
                                                <li>SEO Optimized Landing Page</li>
                                                <li>Dedicated Account Manager</li>
                                                <li>Unlimited Revisions</li>
                                                <li>Turnaround Time - 48 - 72 Hours</li>
                                                <li>Features:</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Ownership rights</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="BRANDING_LANDING_PAGES"
                                                  data-promotion-id="0"
                                                  data-price="149"
                                                  data-price-text="£149"
                                                  data-title="Landing Pages"
                                                  data-package-id="772">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                               
                         </div>
                        </div>
                    </div>
                    <div id="tabWebCorporate" class="tab-pane fade" role="tabpanel" aria-labelledby="tabWebCorporate">
                        <div class="packageList tab-packageSlider owl-carousel owl-theme">
                            <div class="item">
                                <div data-package-box class="pricing-box  ">
                                    <div class="productSku" style="display: none;">WEB_BUSSINESS_BASIC    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Business (Basic)</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>249</h2>
                                                <h3><span>£830</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>3 Page Business Website</li>
                                                <li>5 Revisions</li>
                                                <li>Complete Deployment</li>
                                                <li>Dedicated Designer </li>
                                                <li>Dedicated Professional Developer </li>
                                                <li>Dedicated Account Manager</li>
                                                <li>2 Stock Images</li>
                                                <li>Complete W3C Certified HTML</li>
                                                <li>Google Optimised Sitemap</li>
                                                <li>48 to 72 hours TAT</li>
                                                <li>Features:</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Satisfaction Guaranteed</li>
                                                <li>100% Unique Design Guarantee</li>
                                                <li>100% Money Back Guarantee</li>
                                                <li>All Final File Formats</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_BASIC"
                                                  data-promotion-id="0"
                                                  data-price="249"
                                                  data-price-text="£249"
                                                  data-title="Business (Basic)"
                                                  data-package-id="755">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">WEB_BUSSINESS_PLUS    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Business Plus</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>309</h2>
                                                <h3><span>£1030</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>5 Unique Business Pages Website</li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>Complete Deployment</li>
                                                    <li>2 Dedicated Designer </li>
                                                    <li>Dedicated Professional Developer </li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>3 Stock Images</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Google Optimised Sitemap</li>
                                                    <li>48 to 72 hours TAT</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>Add-Ons:</li>
                                                    <li>Mobile Responsive will be charged additionally</li>
                                                    <li>CMS will be Charged Additionally</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_PLUS"
                                                  data-promotion-id="0"
                                                  data-price="309"
                                                  data-price-text="£309"
                                                  data-title="Business Plus"
                                                  data-package-id="756">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">WEB_BUSSINESS_PRIME    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Business Prime</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>529</h2>
                                                <h3><span>£1763</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>10 Unique Business Pages Website</li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>Complete Deployment</li>
                                                    <li>4 Dedicated Designer </li>
                                                    <li>Dedicated Professional Developer </li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>5 Stock Images</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Google Optimised Sitemap</li>
                                                    <li>48 to 72 hours TAT</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Add-Ons:</li>
                                                    <li>Mobile Responsive will be charged additionally</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_PRIME"
                                                  data-promotion-id="0"
                                                  data-price="529"
                                                  data-price-text="£529"
                                                  data-title="Business Prime"
                                                  data-package-id="757">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                    </div>
                </div>
                <div id="tabWebEcom" class="tab-pane fade" role="tabpanel" aria-labelledby="tabWebEcom">
                    <div class="packageList tab-packageSlider owl-carousel owl-theme">
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_BASIC    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">E-Commerce Basic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>749</h2>
                                                <h3><span>£2496</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Upto 100 Unique Business Pages </li>
                                                    <li>Product Detail Page Design</li>
                                                    <li>Content Management System</li>
                                                    <li>Shopping Cart Integration</li>
                                                    <li>Product Rating & Reviews</li>
                                                    <li>Easy Product Search</li>
                                                    <li>Payment Gateway Integration</li>
                                                    <li>Multi-currency Support</li>
                                                    <li>Shipping Module Integration</li>
                                                    <li>Express Check-out Option</li>
                                                    <li>Pre-defined Tax Calculation</li>
                                                    <li>Customer Account Area</li>
                                                    <li>Complete Deployment</li>
                                                    <li>Social Media Plugins</li>
                                                    <li>Easy Order & Product Management</li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guaranteed</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_BASIC"
                                                  data-promotion-id="0"
                                                  data-price="749"
                                                  data-price-text="£749"
                                                  data-title="E-Commerce Basic"
                                                  data-package-id="758">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>                            
                            </div>                                                
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_PLUS    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">E-Commerce Plus</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>929</h2>
                                                <h3><span>£3096</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Unlimited Products</li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>Unique Banner Slider</li>
                                                    <li>Complete Deployment</li>
                                                    <li>4 Dedicated designer</li>
                                                    <li>2 Dedicated Professional Developer</li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Product Rating & Reviews</li>
                                                    <li>Easy Product Search</li>
                                                    <li>Payment Gateway Integration</li>
                                                    <li>Google Optimised Sitemap</li>
                                                    <li>CMS / Admin Panel Support</li>
                                                    <li>Conceptual and Dynamic Website</li>
                                                    <li>Fully Mobile Responsive</li>
                                                    <li>Online Payment Integration (Optional)</li>
                                                    <li>Social Media Plugins</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guarantee</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_PLUS"
                                                  data-promotion-id="0"
                                                  data-price="929"
                                                  data-price-text="£929"
                                                  data-title="E-Commerce Plus"
                                                  data-package-id="759">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_PRIME    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">E-Commerce Prime</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>1299</h2>
                                                <h3><span>£4330</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Unlimited Products</li>
                                                    <li>Unlimited Revisions</li>
                                                    <li>Complete Deployment</li>
                                                    <li>6 Dedicated Designer</li>
                                                    <li>2 Dedicated Professional Developer</li>
                                                    <li>Dedicated Account Manager</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Google Optimised Sitemap</li>
                                                    <li>Unlimited Products</li>
                                                    <li>CMS / Admin Panel Support</li>
                                                    <li>Full Shopping Cart Integration</li>
                                                    <li>Payment Module Integration</li>
                                                    <li>Easy Product Search</li>
                                                    <li>Product Reviews</li>
                                                    <li>Order Management</li>
                                                    <li>Fully Mobile Responsive</li>
                                                    <li>Product Detail Page Design</li>
                                                    <li>Unlimited Categories</li>
                                                    <li>Product Rating & Reviews</li>
                                                    <li>Payment Gateway Integration</li>
                                                    <li>Multi-currency Support</li>
                                                    <li>Cutomer Log-in Area</li>
                                                    <li>Free Stationery Design:</li>
                                                    <li>5 Social Media Platform Covers</li>
                                                    <li>Bi-Fold Brochure (OR) 2 Sided Flyer Design</li>
                                                    <li>Invoice Design</li>
                                                    <li>Email Signature</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guarantee</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                           
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_PRIME"
                                                  data-promotion-id="0"
                                                  data-price="1299"
                                                  data-price-text="£1299"
                                                  data-title="E-Commerce Prime"
                                                  data-package-id="760">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                    </div>
                </div>
                <div id="tabAnimation" class="tab-pane fade" role="tabpanel" aria-labelledby="tabAnimation">
                    <div class="packageList tab-packageSlider owl-carousel owl-theme">
                        <div class="item">
                            <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">ANIMATION_VIDEO_STARTUP    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Video Startup</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>399</h2>
                                                <h3><span>£1330</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>Whiteboard Video</li>
                                                <li>Custom Artwork; No Stolen Images</li>
                                                <li>Unlimited Storyboard Revisions</li>
                                                <li>Professional Voice - Over</li>
                                                <li>Background Music</li>
                                                <li>Exotic Animations</li>
                                                <li>HD Video Production</li>
                                                <li>Add video script £120/minute</li>
                                                <li>30 seconds Video Duration</li>
                                                <li>3 Weeks Delivery Time</li>
                                                <li>100% Ownership Rights</li>
                                                <li>Moneyback Guarantee</li>
                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="ANIMATION_VIDEO_STARTUP"
                                                  data-promotion-id="0"
                                                  data-price="399"
                                                  data-price-text="£399"
                                                  data-title="Video Startup"
                                                  data-package-id="764">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                        <div class="item">
                             <div data-package-box class="pricing-box  ">
                                <div class="productSku" style="display: none;">ANIMATION_VIDEO_BASIC    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Video Basic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>699</h2>
                                                <h3><span>£2330</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Motion Graphics / Cut-out Video</li>
                                                    <li>Custom Artwork; No Stolen Images</li>
                                                    <li>Unlimited Storyboard Revisions</li>
                                                    <li>Background Music / Sound Effects</li>
                                                    <li>Exotic Animations</li>
                                                    <li>HD Video Production</li>
                                                    <li>Add video script £120/minute</li>
                                                    <li>30 seconds Video Duration</li>
                                                    <li>3-4  Weeks Delivery Time</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>Moneyback Guarantee</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="ANIMATION_VIDEO_BASIC"
                                                  data-promotion-id="0"
                                                  data-price="699"
                                                  data-price-text="£699"
                                                  data-title="Video Basic"
                                                  data-package-id="765">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">ANIMATION_VIDEO_PLUS    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Video Plus</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>899</h2>
                                                <h3><span>£2996</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>2 Character Illustration / 2D Cartoon Animation</li>
                                                    <li>Custom Artwork; No Stolen Images</li>
                                                    <li>Unlimited Storyboard Revisions</li>
                                                    <li>Initial Script Writing</li>
                                                    <li>Professional Voice – Over</li>
                                                    <li>Background Music / Sound Effects</li>
                                                    <li>Exotic Animations</li>
                                                    <li>HD Video Production</li>
                                                    <li>30 seconds Video Duration</li>
                                                    <li>4-5 Weeks Delivery Time</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>Moneyback Guarantee</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="ANIMATION_VIDEO_PLUS"
                                                  data-promotion-id="0"
                                                  data-price="899"
                                                  data-price-text="£899"
                                                  data-title="Video Plus"
                                                  data-package-id="766">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">ANIMATION_VIDEO_CLASSIC    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Video Classic</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>299</h2>
                                                <h3><span>£996</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>WhiteBoard Video</li>
                                                <li>60 Seconds Video Duration</li>
                                                <li>Custom Artwork; No Stolen Images</li>
                                                <li>Unlimited Storyboard Revisions</li>
                                                <li>Background Music</li>
                                                <li>Exotic Animations</li>
                                                <li>HD Video Production</li>
                                                <li><strong>Add Video Script £100/Minute</strong></li>
                                                <li>3-4 Weeks Delivery Time</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Money-Back Guarantee</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="ANIMATION_VIDEO_CLASSIC"
                                                  data-promotion-id="0"
                                                  data-price="299"
                                                  data-price-text="£299"
                                                  data-title="Video Classic"
                                                  data-package-id="773">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                
                        </div>
                        <div class="item">
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">ANIMATION_VIDEO_ELITE    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Video Elite</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>399</h2>
                                                <h3><span>£1330</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                <li>Custom 2D Character Illustration</li>
                                                <li>60 Seconds Video Duration</li>
                                                <li>Custom Artwork; No Stolen Images</li>
                                                <li>Initial Script Writing</li>
                                                <li>Unlimited Storyboard Revisions</li>
                                                <li>Background Music</li>
                                                <li>Exotic Animations</li>
                                                <li>HD Video Production</li>
                                                <li><strong>Add Video Script £100/Minute</strong></li>
                                                <li>4-5 Weeks Delivery Time</li>
                                                <li>100% Ownership Rights</li>
                                                <li>100% Money-Back Guarantee</li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="ANIMATION_VIDEO_ELITE"
                                                  data-promotion-id="0"
                                                  data-price="399"
                                                  data-price-text="£399"
                                                  data-title="Video Elite"
                                                  data-package-id="774">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                               
                         </div>
                        </div>
                    </div>
                    <div id="tabWebCombo" class="tab-pane fade" role="tabpanel" aria-labelledby="tabWebCombo">
                        <div class="packageList tab-packageSlider owl-carousel owl-theme">
                            <div>
                                <div data-package-box class="pricing-box  ">
                                    <div class="productSku" style="display: none;">WEB_COMBO_STARTER_COMBO    </div>
                                    <div>
                                        <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Starter Combo</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>1099</h2>
                                                <h3><span>£3663</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Upto 15 Unique Pages Website</li>
                                                    <li>Conceptual and Dynamic Website</li>
                                                    <li>Content Management System (CMS)</li>
                                                    <li>Mobile Responsive</li>
                                                    <li>Easy Product Search</li>
                                                    <li>Product Reviews</li>
                                                    <li>Unlimited Products</li>
                                                    <li>Unlimited Categories</li>
                                                    <li>Promotional Product Showcase</li>
                                                    <li>New Product Showcase</li>
                                                    <li>Full Shopping Cart Integration</li>
                                                    <li>Payment Module Integration</li>
                                                    <li>Sales & Inventory Management</li>
                                                    <li>JQuery Slider</li>
                                                    <li>3 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                    <li>FREE Google Friendly Sitemap</li>

                                                    <li>Custom Email Address</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guarantee</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_STARTER_COMBO"
                                                  data-promotion-id="0"
                                                  data-price="1099"
                                                  data-price-text="£1099"
                                                  data-title="Starter Combo"
                                                  data-package-id="761">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                        
                        </div>                                                                                                                              
                        <div>
                            <div data-package-box class="pricing-box  "><div class="productSku" style="display: none;">WEB_COMBO_BUSINESS_COMBO    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Business Combo</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>1599</h2>
                                                <h3><span>£5330</span></h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Upto 15 Unique Pages Website</li>
                                                    <li>Conceptual and Dynamic Website</li>
                                                    <li>Content Management System (CMS)</li>
                                                    <li>Mobile Responsive</li>
                                                    <li>Online Reservation/Appointment Tool (Optional)</li>
                                                    <li>Online Payment Integration (Optional)</li>
                                                    <li>Custom Forms</li>
                                                    <li>Lead Capturing Forms (Optional)</li>
                                                    <li>Striking Hoover Effects</li>
                                                    <li>Newsfeed Integration</li>
                                                    <li>Social Media Integration</li>
                                                    <li>15 Stock images</li>
                                                    <li>JQuery Slider</li>
                                                    <li>4 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                    <li>FREE Google Friendly Sitemap</li>
                                                    <li>Custom Email Address</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guarantee</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_BUSINESS_COMBO"
                                                  data-promotion-id="0"
                                                  data-price="1599"
                                                  data-price-text="£1599"
                                                  data-title="Business Combo"
                                                  data-package-id="762">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>                                                        
                        </div>
                        <div>
                            <div data-package-box class="pricing-box  popular">
                                <div class="productSku" style="display: none;">WEB_COMBO_ULTIMATE_COMBO    </div>
                                <div>
                                    <div class="card">
                                        <div class="card-header">
                                            <p class="bestSeller">Ultimate Combo</p>
<!--                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                            <div class="price">
                                                <h2><span>£</span>2099</h2>
                                                <h3><span>£6996</span>70% OFF</h3>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="scroll" data-package-scroll>
                                              <ul>
                                                    <li>Unlimited Page Website</li>
                                                    <li>Custom Content Management System (CMS)</li>
                                                    <li>Unique Pages and UI Design</li>
                                                    <li>Complete Custom Development</li>
                                                    <li>Process Automation Tools</li>
                                                    <li>Newsfeed Integration</li>
                                                    <li>Social Media Plugins Integration</li>
                                                    <li>Upto 20 Stock images</li>
                                                    <li>JQuery Slider</li>
                                                    <li>FREE Google Friendly Sitemap</li>
                                                    <li>Custom Email Address</li>
                                                    <li>5 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                    <li>Complete W3C Certified HTML</li>
                                                    <li>Features:</li>
                                                    <li>100% Ownership Rights</li>
                                                    <li>100% Satisfaction Guarantee</li>
                                                    <li>100% Unique Design Guarantee</li>
                                                    <li>100% Money Back Guarantee</li>
                                                    <li>All Final File Formats</li>
                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                    </ul>                                            
                                                </div>
                                        </div>
                                        <div class="card-footer">
                                            <ul class="list-center">
                                                <li>
                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_ULTIMATE_COMBO"
                                                  data-promotion-id="0"
                                                  data-price="2099"
                                                  data-price-text="£2099"
                                                  data-title="Ultimate Combo"
                                                  data-package-id="763">Order now</button>
                                                </li>
                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <h4>Key Features</h4>
                            <ul class="list-center satisfaction text-center">
                                <li>
                                    <i class="sprite_1 sprite-sG"></i>
                                    <p>100% Satisfaction Guaranteed</p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-cS"></i>
                                    <p>24 X 7 Customer Support</p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-oR"></i>
                                    <p>100% Ownership Rights</p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-mBG"></i>
                                    <p>Money Back Guarantee</p>
                                </li>
                                <li>
                                    <i class="sprite_1 sprite-iSD"></i>
                                    <p>Industry Specific Designers</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
</section>
