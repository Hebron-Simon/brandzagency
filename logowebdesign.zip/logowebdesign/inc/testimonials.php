<section class="pg" data-aos="fade-down">
                <div class="testimonial">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <h2 class="title">this is what industry's top clientele sounds like</h2>
                                <p>
                                The secret to our long-term success in the industry lies in the hearts of our customers
                                </p>
                                <ul class="testiProfile">
                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/chris-slater.jpg" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                Their designs are creative and assistants are cooperative. What else can I ask for in a designing service? Logos Web Design is my all-time favorite design agency to work with
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Raymond Richards,
                                                <span>Fashion retailer.</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/evtech.jpg" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                Their designing team helped me with my startup from the beginning and gave full support and maintenance until I reached my desired goals with my branding expectations. I can never thank them enough for their impeccable services.
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Gerald E. Beltz,
                                                <span>Entrepreneur.</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/merkurius.jpg" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                Working in the media marketing agency, I always recommend Logos Web Design to my clients for a better success rate of the entire marketing strategy and they never fail to deliver. Looking forward to work with them in the future.
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Jonathan C.,
                                                <span>Media Marketing Agent.</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/thaiFood.jpg" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                I tried creating it with free online designing tools but wasn’t satisfied with the results. I’m loving my restaurant’s new logo. It is everything I asked for, professional services really speak for themselves.
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Anthony Henry, 
                                                <span>Restaurant owner</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/sg.png" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                “Working with them was as effortless and easy as working with an old friend. They listen, understand and deliver.”
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Angel Galsso, 
                                                <span>Local retailer.</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="testImg">
                                            <img src="<?php echo $main_url ; ?>img/hw.png" alt="sg">
                                        </div>
                                        <div class="testCont">
                                            <p>
                                                <i class="sprite sprite-comma-r"></i>
                                                “Their animated logo services helped grow my branding within days. I had better sales to prospect ratio and better consumer reactions to advertising ventures. Thank you, Logos Web Design.”
                                                <i class="sprite sprite-comma-s"></i>
                                            </p>
                                        </div>
                                        <div class="author">
                                            <h6>
                                                Timothy Ross, 
                                                <span>Entrepreneur.</span>
                                            </h6>
                                            <i class="sprite sprite-rating"></i>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>