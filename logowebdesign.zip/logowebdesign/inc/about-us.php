<section class="pg whyUs bg-grey" data-aos="fade-up">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="title">about us</h2>
                            <div class="why-content">
                                <div class="col-lg-6">
                                    <img src="<?php echo $main_url ; ?>img/whyUs.jpg" alt="whyUs">
                                </div>
                                <div class="col-lg-6">
                                    <h3>We help <strong>companies position</strong> themselves in their <strong>ideal market.</strong> </h3>
                                    <p>Logos Web Design is your ultimate route to branding and growth. Our years of experience in the field has given us enough exposure to analyze and escalate any business through target-based designing elements. Our designs are strategized and created by the industry’s top, leaving no room for doubt. </p>
                                    <ul class="whyList">
                                        <li>
                                            <i class="sprite_1 sprite-design"></i>
                                            <h6>Immaculate Design</h6>
                                        </li>
                                        <li>
                                            <i class="sprite_1 sprite-winning"></i>
                                            <h6>Award Winning Designers</h6>
                                        </li>
                                        <li>
                                            <i class="sprite sprite-y3"></i>
                                            <h6>Guaranteed Satisfaction</h6>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>                
            </section>