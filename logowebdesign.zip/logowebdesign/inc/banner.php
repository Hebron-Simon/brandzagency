<body class="index">
        <main>
            <div class="slider">
                
                <section class="banner banner_three">
                    <div class="banner-img">
                        <img src="<?php echo $main_url ; ?>img/banner-home_2.png" alt="banner">
                    </div>
                    <div class="banner-content">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7 col-12">
                                    <div class="sliderContent" data-animation="fadeInLeft" data-delay="0.5s">
                                        <div class="brand">
                                            <h2>We Help Your </h2>
                                            <h1>BRAND</h1>
                                            <h3 style="font-size: 1.85rem;">Grow with Impeccable Logo Designs</h3>
                                        </div>
                                        <p>
                                        We are committed towards providing professional logo designs tailored to your brand’s culture, core values & distinction.
                                        </p>
                                        <a href="#" class="btn btn-rounded btn-black popupBox" data-toggle="modal" data-target="getQuote" data-animation="slideInUp" data-delay="1.5s">lets get started</a>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-12" >

                                </div>
                            </div>
                            <div class="banner_img"><img src="<?php echo $main_url ; ?>img/banner-home2.png" alt="imag" data-animation="fadeInRight" data-delay="1s" class="slide3_area"></div>
                        </div>
                    </div>
                </section>
                <section class="banner banner_two">
                    <div class="banner-img">
                        <img src="<?php echo $main_url ; ?>img/banner-home_3.jpg" alt="banner">
                    </div>
                    <div class="banner-content">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-7 col-12">
                                    <div class="sliderContent" data-animation="fadeInLeft" data-delay="0.5s">
                                        <div class="brand">
                                            <h2>We Make the Best</h2>
                                            <h1>Websites</h1>
                                            <h3 style="font-size: 1.675rem;">For Your brand at the most affordable price</h3>
                                        </div>
                                        <p>
                                        The foundation of a strong virtual presence is built on a professional Website. Impress your visitors with an impression they can't shake off.
                                        </p>
                                        <a href="#" class="btn btn-rounded btn-black popupBox" data-toggle="modal" data-target="getQuote" data-animation="slideInUp" data-delay="1.5s">lets get started</a>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-12">
                                    <img src="<?php echo $main_url ; ?>img/banner-home3.png" alt="" data-animation="fadeInRight" data-delay="1s"
                                    class="slide2_area">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section class="banner banner_one">
                    <div class="banner-img">
                        <img src="<?php echo $main_url ; ?>img/bg-slider-one.png" alt="banner">
                    </div>
                    <div class="banner-content">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-8 col-12">
                                    <div class="sliderContent" data-animation="fadeInLeft" data-delay="0.5s">
                                        <div class="brand">
                                            <h2>Humanize Your Brand with </h2>
                                            <h1>Animations</h1>
                                            <h3>That Bring in More Leads and ROI</h3>
                                        </div>
                                        <p>We’ve helped thousands of brands discover their message, create their video and deliver their story. We can do the same for you! </p>
                                        <a href="#" class="btn btn-rounded btn-black popupBox" data-toggle="modal" data-target="getQuote" data-animation="slideInUp" data-delay="1.5s">lets get started</a>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-12">
                                    <img src="<?php echo $main_url ; ?>img/fire_girl.png" alt="imag" data-animation="fadeInRight" data-delay="1s" class="fire_area">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>