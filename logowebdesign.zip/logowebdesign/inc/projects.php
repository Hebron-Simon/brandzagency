<section class="pg glimpse" data-aos="fade-down">
                <div id="exTab3">   
                    <div class="container">
                        <div class="row">
                            <div class="col-12 text-center">
                                <h2 class="title">LATEST PROJECTS</h2>
                                <p>Our portfolio comprises of various nature of projects, executed perfectly according to their relevant industry.</p>
                                <ul class="nav nav-pills tab-pill">
                                    <li class="first active">
                                        <a href="#pk1_1" class="active show" data-toggle="tab" aria-expanded="true">logo</a>
                                    </li>
                                    <li class="">
                                        <a href="#pk2_1" data-toggle="tab">Branding</a>
                                    </li>
                                    <li class="">
                                        <a href="#pk3_1" data-toggle="tab">website</a>
                                    </li>
                                    <li>
                                        <a href="#pk4_1" data-toggle="tab">Video</a>
                                    </li>
                                    <li>
                                        <a href="#pk5_1" data-toggle="tab">Mobile App</a>
                                    </li>
                                </ul>                        
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid">
                        <div class="row">
                            <div class="tab-content clearfix d-block mt-4">
                                <div id="pk1_1" class="tab-pane active">
                                    <div class="workGal">
                                        <ul class="workList">
                                            <li><a href="<?php echo $main_url ; ?>img/lp1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp1.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp2.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp3.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp4.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp5.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp6.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp7.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp8.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp9.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/lp10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/lp10.jpg" alt=""></li>
                                        </ul>
                                    </div>
                                </div>
                                <div id="pk2_1" class="tab-pane">
                                    <div class="workGal">
                                        <ul class="workList">
                                            <li><a href="<?php echo $main_url ; ?>img/pp1.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp1.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp2.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp2.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp3.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp3.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp4.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp4.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp5.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp5.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp6.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp6.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp7.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp7.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp8.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp8.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp9.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp9.png" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/pp10.png" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/pp10.png" alt=""></li>
                                        </ul>
                                    </div>
                                </div>
                                <div id="pk3_1" class="tab-pane">
                                    <div class="workGal">
                                        <ul class="workList">
                                            <li><a href="<?php echo $main_url ; ?>img/vd1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd1.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd2.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd3.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd4.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd5.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd6.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd7.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd8.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd9.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/vd10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/vd10.jpg" alt=""></li>
                                        </ul>
                                    </div>
                                </div>
                                <div id="pk4_1" class="tab-pane">
                                    <div class="workGal">
                                        <ul class="workList">
                                            <li><a href="https://www.youtube.com/watch?v=t6i7Co_vvHY" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-1.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?time_continue=13&v=NCurquviOds" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-2.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=wEIfBqjenLE" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-3.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=C3WpLAE_rgs" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-4.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=Trz4CVTLQbU" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-5.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=MP--HVg6OSg" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-6.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=B_Cmd3sIOxQ" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-7.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=tOEoyL5qnVg" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-8.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=ZSf7A15CitA" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-9.jpg" alt=""></li>
                                            <li><a href="https://www.youtube.com/watch?v=55PhVQfugUs" class="video"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/an-10.jpg" alt=""></li>
                                        </ul>
                                    </div>
                                </div>
                                <div id="pk5_1" class="tab-pane">
                                    <div class="workGal">
                                        <ul class="workList">
                                            <li><a href="<?php echo $main_url ; ?>img/w1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w1.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w2.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w3.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w4.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w5.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w6.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w7.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w8.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w9.jpg" alt=""></li>
                                            <li><a href="<?php echo $main_url ; ?>img/w10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo $main_url ; ?>img/w10.jpg" alt=""></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="pg" data-aos="fade-down">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <ul class="list-center mt-2 mb-3">
                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-shadow btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                <li><a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-white-outline active btn-shadow btn-lg chat">chat now</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>