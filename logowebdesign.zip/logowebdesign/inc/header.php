<?php 

//Primary Values

$brand_name = "Logos Web Design";

$primary_phone = "+1-123-456-7890";

$primary_phone_link = "tel:+11234567890";

$primary_email = "info@logoswebdesign.com";

$primary_email_link = "mailto:info@logoswebdesign.com";

$primary_address = "1341 W. Mockingbird Lane, Suite 600W, Dallas, Texas 75247";

$main_url = "http://localhost/brandzagency/";

$chat_open = "javascript:void(Tawk_API.toggle())";


//Secondary Values

$secondary_phone = "+111-111-1111";

$secondary_email = "info@brandzagency.com";

?>


    <title>Logos Web Design | Home</title>

    <meta name="description" content="Logos Web Design is an industry-leading digital branding agency taking care of all your logo, website, print, SEO and animation needs for over a decade">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="shortcut icon"  href="<?php echo $main_url ; ?>img/favicon.ico" type="image/x-icon" >
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/slick.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/intlTelInput.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/jQuery-plugin-progressbar.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/web.min.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo $main_url ; ?>css/main.css">

  <!-- Google Tag Manager -->

</head>

<body>
            <!-- Google Tag Manager (noscript) -->
<!-- <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P7DQ68L"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript> -->
<!-- End Google Tag Manager (noscript) -->
        <header class="bg-black">
            <nav class="navbar navbar-expand-md">
                <a class="navbar-brand" href="<?php echo $main_url ; ?>index.php">
                    <img src="<?php echo $main_url ; ?>img/white_logo.png" alt="logo">
                </a>
                <div id="hamburger" href="#"><span></span></div>

                <div class="collapse navbar-collapse" id="mainNavbar">
                    <div class="ml-auto d-flex align-items-center">
                        <ul class="navbar-nav">
                            <li class="nav-item ">                            
                                <a class="nav-link" href="<?php echo $main_url ; ?>logo-overview.php">Logo</a>
                            </li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>branding.php">Branding</a></li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>web.php">website</a></li>
                            <!-- <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>seo.php">Seo</a></li> -->
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>animation.php">Animation</a></li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>app-overview.php">apps</a></li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>portfolio.php">portfolio</a></li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>packages.php">Packages</a></li>
                            <li class="nav-item "><a class="nav-link" href="<?php echo $main_url ; ?>about.php">About</a></li>
                        </ul>
                        <ul class="contact-menu">
                            <li>
                                <a class="nav-link chat" href="javascript:void(0);"><i class="sprite sprite-msg-w"></i>Talk to us</a>
                                <a class="nav-link" href="<?php echo$primary_phone_link; ?>"><i class="sprite sprite-phone-w"></i><?php echo$primary_phone; ?></a>
                            </li>
                            <li>
                                <a href="#" class="btn btn-rounded btn-white-outline popupBox" data-toggle="modal" data-target="getQuote">get a free quote</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>