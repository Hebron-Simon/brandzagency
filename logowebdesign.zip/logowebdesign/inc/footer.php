</main>
<section>
<ul class="social">
        <li class="fb"><a href="https://www.facebook.com/#" target="_blank"><i class="fa fa-facebook-f"></i></a></li>
        <li class="yt"><a href="https://www.pinterest.com/#" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
        <li class="ld"><a href="https://www.linkedin.com/#"  target="_blank"><i class="fa fa-linkedin"></i></a></li>
        <li class="td"><a href="https://www.trustpilot.com/#" target="_blank"><i class="fa fa-star" aria-hidden="true"></i></a></li>
        <li class="tw"><a href="https://www.twitter.com/#"" target="_blank"><i class="fa fa-twitter"></i></a></li>
    </ul>
</section>
<footer>
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="footer-menu" >
                    <h4>Services</h4>
                    <ul class="arrow-list">
                        <li><a href="<?php echo $main_url ; ?>logo-overview.php">Custom Logo Design</a>&gt;</li>
                        <li><a href="<?php echo $main_url ; ?>animation.php#2a">Animation Services</a>&gt;</li>
                        <li><a href="<?php echo $main_url ; ?>web.php">Web Design and Development</a>&gt;</li>
                        <!-- <li><a href="<?php echo $main_url ; ?>seo.php">SEO Services</a>&gt;</li>-->
                        <li><a href="<?php echo $main_url ; ?>app-overview.php">App Design and Development</a>&gt;</li>
                    </ul>
                </div>
            </div>
            <div class="col">
                <div class="footer-menu">
                    <h4>Package</h4>
                    <ul class="arrow-list">
                        <li><a href="<?php echo $main_url ; ?>logo-overview.php#2a">Logo Packages</a></li>
                        <li><a href="<?php echo $main_url ; ?>animation.php#2a">Animation Packages</a></li>
                        <li><a href="<?php echo $main_url ; ?>web.php#2a">Web Packages</a></li>
                        <!-- <li><a href="<?php echo $main_url ; ?>seo.php#3a">SEO Packages</a></li>-->
                    </ul>
                </div>
            </div>
            <div class="col">
                <div class="footer-menu">
                    <h4>Quick Links</h4>
                    <ul class="arrow-list">
                        <li><a href="<?php echo $main_url ; ?>about.php">About Us</a></li>
                        <li><a href="<?php echo $main_url ; ?>portfolio.php">Portfolio</a></li>
                        <li><a href="<?php echo $main_url ; ?>testimonial.php">Testimonial</a></li>
                        <li><a href="<?php echo $main_url ; ?>terms-conditions.php">Terms of use</a></li>
                        <li><a href="<?php echo $main_url ; ?>privacy.php">Privacy Policy</a></li>
                        <li><a href="<?php echo $main_url ; ?>contact.php">Contact</a></li>
                    </ul>
                </div>
            </div>
            <div class="col">
                <div class="footer-menu">
                    <h4>Contact</h4>
                    <ul class="footer-detail">
                        <li>
                            <a href="<?php echo$chat_open;?>" class="chat">
                                <i class="sprite sprite-f-msg"></i>talk to us</a>
                        </li>
                        <li>
                            <a href="<?php echo $primary_phone_link; ?>">
                                <i class="sprite sprite-f-call"></i><?php echo $primary_phone ; ?></a>
                        </li>
                        <li>
                            <a href="<?php echo $primary_email_link ; ?>">
                                <i class="sprite sprite-f-env"></i>
                                click here to email
                            </a>
                        </li>
                    </ul>
                    <a href="#" class="btn btn-rounded btn-white-outline btn-block popupBox" data-toggle="modal" data-target="getQuote">get a free quote</a>
                </div>
            </div>
            <div class="col">
                <div class="footer-menu px-3" style="background: #201d28;">
                    <h4>
                        <a href="<?php echo $main_url ; ?>index.php">
                            <img src="<?php echo $main_url ; ?>img/white_logo.png" alt="logo">
                        </a>
                    </h4>
                    <p class="mt-4">
                        Logos Web Design is all about creativity, beauty and cost-effectiveness. Logos Web Design  is your one-stop agency that offers turn-key design solutions.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="cprBar">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="cpr">
                        <a href="#">DISCLAIMER</a>
                        <p>© 2022 Logos Web Design | All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Sticky whatsapp Icon -->
<div>
    <a href="https://api.whatsapp.com/send?phone=+1234567890&amp;text=Hi" class="whatspp-icon" data-pagespeed-url-hash="1234567890" onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
        <img src="<?php echo$main_url;?>img/whatsapp.png" class="img-fluid" />   
    </a>
</div>
<!-- End Sticky whatsapp Icon -->

<div class="modal fade contact-popup" id="getQuote" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="banner">
                    <div class="card w-100" data-aos="fade-up">
                        <div class="card-header">
                            <h2>70% DISCOUNT</h2>
                        </div>
                        <div class="card-body">
                            <h3>
                                Let’s start your project,
                                <strong>Drop us your details!</strong>
                            </h3>
                            <div data-form-type="signup_form">
                                <form class="leadForm" method="post" enctype="multipart/form-data" action="javascript:void(0)">
                                    <!--hidden required values-->
                                        <input type="hidden" id="formType" name="formType">
                                        <input type="hidden" id="referer" name="referer">
                                    <div class="form-group">
                                        <label for="name-1" class="d-none">Name</label>
                                        <input type="text" name="name" required  class="form-control btn-rounded" id="name-1" placeholder="Your Name">
                                    </div>
                                    <div class="form-group">
                                        <label for="email-1" class="d-none">email</label>
                                        <input type="email" name="email" required class="form-control btn-rounded" id="email-1" placeholder="Email Address">
                                    </div>
                                    <div class="form-group">
                                        <label for="phone-1" class="d-none">phone</label>
                                        <input type="tel" maxlength="12" name="phone" required class="form-control btn-rounded" id="phone-1" placeholder="Phone Number">
                                    </div>
                                    <div id="formResult"></div>
                                    <div class="form-group">
                                        <button name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="<?php echo $main_url ; ?>js/intlTelInput.js"></script>
<script src="<?php echo $main_url ; ?>js/jquery.waypoints.js"></script>
<script src="<?php echo $main_url ; ?>js/jquery.countup.min.js"></script>
<script src="<?php echo $main_url ; ?>js/slick.min.js"></script>
<script src="<?php echo $main_url ; ?>js/slimScroll.js"></script>
<script src="<?php echo $main_url ; ?>js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo $main_url ; ?>js/jQuery-plugin-progressbar.js"></script>
<script src="<?php echo $main_url ; ?>js/plugins.js"></script>
<script src="<?php echo $main_url ; ?>js/jquery.validate.min.js"></script>
<script>
    $(function(){
        // $('.packageList .card-body ul').slimScroll({
        //     height: '210px',
        //     railVisible: true,
        //     alwaysVisible: true,
        //     railColor: '#e8e8e8',
        //     color:'#6c6c6c',
        //     railOpacity: 0.3
        // });
        $('.comments .card-body').slimScroll({
            height: '110px',
            railVisible: true,
            alwaysVisible: true,
            railColor: '#e8e8e8',
            color:'#6c6c6c',
            railOpacity: 0.3
        });
        
    });
    $(document).ready(function(){
        $('.popupBox').click(function(){
            $('#getQuote').modal('show')
        });
        $('.service-desc .btn').on('click', function () {
            $('.signupForm #name').focus()
        })
        $('#hamburger').click(function() {
            $(this).toggleClass( "active" );
            $('#mainNavbar').slideToggle()
        });

        $('ul.tabs li').click(function(){
            var tab_id = $(this).attr('data-tab');

            $('ul.tabs li').removeClass('current');
            $('.tab-content').removeClass('current');

            $(this).addClass('current');
            $("#"+tab_id).addClass('current');
        });

        $('.slider').on('init', function(e, slick) {
            var $firstAnimatingElements = $('.banner:first-child').find('[data-animation]');
            doAnimations($firstAnimatingElements);
        });
        $('.slider').slick({
            dots: true,
            arrows: true,
            speed: 300,
            fade: true,
            prevArrow:"<button type='button' class='slick-prev'><img src='<?php echo $main_url ; ?>img/arrow.png'/><span class='num'></span></button>",
            nextArrow:"<button type='button' class='slick-next'><span class='num'></span><img src='<?php echo $main_url ; ?>img/arrow.png'/></button>",
        });

        $('.slider').on('beforeChange', function(e, slick, currentSlide, nextSlide) {
            var $animatingElements = $('.banner[data-slick-index="' + nextSlide + '"]').find('[data-animation]');
            doAnimations($animatingElements);
        });
        function doAnimations(elements) {
            var animationEndEvents = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
            elements.each(function() {
                var $this = $(this);
                var $animationDelay = $this.data('delay');
                var $animationType = 'animated ' + $this.data('animation');
                $this.css({
                    'animation-delay': $animationDelay,
                    '-webkit-animation-delay': $animationDelay
                });
                $this.addClass($animationType).one(animationEndEvents, function() {
                    $this.removeClass($animationType);
                });
            });
        }

        appendNumber();
        function appendNumber(params) {
            var currentSlick = $('.slider').slick('getSlick');
            var currentSlider= $('.slider').slick('slickCurrentSlide')
            $(".slider .slick-prev .num").html(currentSlick.slideCount);
            $(".slider .slick-next .num").html(currentSlider + 2);
            $('.slider').on('afterChange', function(slick, currentSlide){
                $(".slider .slick-prev .num").html(currentSlide.currentSlide);
                var temp = currentSlide.currentSlide + 2;
                if(temp > currentSlide.slideCount){
                    temp = 1
                    $(".slider .slick-next .num").html(temp);
                }else{
                    $(".slider .slick-next .num").html(currentSlide.currentSlide + 2);
                }
            });

        }


            $('.tab-packageSlider').owlCarousel({
                dots: true,
                items: 3,
                margin: 30,
                nav: false,
                rewind: true,
                autoplay: true,
                responsive:{
                    0:{
                        items:1
                    },
                    600:{
                        items:2
                    },
                    1000:{
                        items:3
                    }
                }
            });


        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            // let $tabPane = $($(this).attr('href'));
            // $('.tab-packageSlider', $tabPane).slick('refresh');
            // $('.tab-packageSlider', $tabPane).slick('setPosition');
        });

        $('#serviceSlider').slick({
            dots: true,
            arrows: false,
            speed: 300,
            autoplay: true,
            fade: true,
            cssEase: 'linear'
        });
        $('.satisfaction').slick({
            dots: false,
            slidesToShow: 5,
            slidesToScroll: 1,
            arrows: false,
            speed: 300,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 4
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 500,
                    settings: {
                        slidesToShow: 2
                    }
                }
            ]
        });
        $('.nav-pills a').on('shown.bs.tab', function() {
            let $tabPane = $($(this).attr('href'));
            $('.satisfaction', $tabPane).slick('refresh');
        });
        $('.creativity').slick({
            dots: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            speed: 300,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
        $('.nav-pills a').on('shown.bs.tab', function() {
            let $tabPane = $($(this).attr('href'));
            $('.creativity', $tabPane).slick('refresh');
        });

        $('.progressContent').slick({
            dots: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            speed: 300,
            autoplay: false,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 767,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });

        $('.whyList').slick({
            dots: false,
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows: false,
            speed: 300,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 500,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
        $('.testiProfile').slick({
            dots: false,
            slidesToShow: 2,
            slidesToScroll: 1,
            arrows: true,
            speed: 300,
            autoplay: true,
            prevArrow:"<button type='button' class='slick-prev'><img src='<?php echo $main_url ; ?>img/arrow.png'/></button>",
            nextArrow:"<button type='button' class='slick-next'><img src='<?php echo $main_url ; ?>img/arrow.png'/></button>",
            responsive: [
                {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 1
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
        $('.secretDelievery ul.list-center').slick({
            dots: false,
            slidesToShow: 5,
            slidesToScroll: 1,
            arrows: false,
            speed: 300,
            autoplay: true,
            responsive: [
                {
                    breakpoint: 1199,
                    settings: {
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 500,
                    settings: {
                        slidesToShow: 1
                    }
                }
            ]
        });
        $('.nav-pills a').on('shown.bs.tab', function() {
            let $tabPane = $($(this).attr('href'));
            $('.secretDelievery ul.list-center', $tabPane).slick('refresh');
        });

        $('.count-num').countUp({
            'time': 2000,
            'delay': 10

        });
        $('.workList').magnificPopup({
            delegate: 'a',
            type: 'image',
            callbacks: {
                elementParse: function(item) {
                    // Function will fire for each target element
                    // "item.el" is a target DOM element (if present)
                    // "item.src" is a source that you may modify
                    console.log(item.el.context.className);
                    console.log(item)
                    if(item.el.context.className == 'video') {
                        item.type = 'iframe'
                    } else {
                        item.type = 'image',
                            item.tLoading = 'Loading image #%curr%...',
                            item.mainClass = 'mfp-img-mobile',
                            item.image = {
                                tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
                            }
                    }

                }
            },
            gallery: {
                enabled: true,
                navigateByImgClick: true,
                preload: [0,1]
            }
        });
        $(".progress-bar").loading();

        AOS.init({
            once: true
        });
        var hash = document.location.hash;
        if (hash) {
            $('.nav-pills a[href='+hash+']').tab('show');
        }
        $('.nav-pills a').on('shown.bs.tab', function (e) {
            window.location.hash = e.target.hash;
        });
    })
</script>
<!-- Chat Code -->
<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=b51f21cf-c1da-43d9-ae76-fd7de4ceeac0"> </script> <script>     $('.chat, .chatt').click(function(){         $zopim.livechat.window.toggle()     }); </script>
<!-- Mouse Flow -->


<!-- Forms validation -->
<script src="<?php echo $main_url ; ?>js/form_validator.min.js"></script>

<!-- Main Requests Helper -->
<script src="<?php echo $main_url ; ?>js/core/ajaxHelper.js"></script>

<!-- General Functions -->
<script src="<?php echo $main_url ; ?>js/core/generalHelper.js"></script>

<!-- Sweet Alert -->
<link rel="stylesheet" type="text/css" href="<?php echo $main_url ; ?>js/alert/sweetalert.css">
<script src="<?php echo $main_url ; ?>js/alert/sweetalert.min.js"></script>

<!-- Captcha Script -->
<!-- <script src="https://www.google.com/recaptcha/api.js?onload=onLoadCaptcha&render=explicit"></script> -->

<!-- Initialzing Script -->
<script>
	
	// validation Initializing
    $.validate({});
    
    // Captcha Key Initializing
    // var captchaKey = ""

</script>

<!-- Lead Management Of Form -->
<script src="<?php echo $main_url ; ?>js/core/leadManagement.js"></script>
    <script src="<?php echo $main_url ; ?>js/core/pricingManagement.js"></script></body>


    <script>
        $(window).bind('load resize', function () {
                    // $('#parent').append('<div>hello</div>');    
                    var viewWidth = $(window).width();
                    if(viewWidth > 767){
                        $('#serviceSlider').on('afterChange', function(slick, currentSlide){
                        var get_index = currentSlide.currentSlide;
                        switch(get_index){
                            case 0:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/PS-bg.png" class="bg-img">');
                                break;
                            case 1:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/SEO-bg.png" class="bg-img">');
                                break;
                            case 2:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/VD-bg.png" class="bg-img">');
                                break;
                            case 3:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/ADD-bg.png" class="bg-img">');
                                break;
                            case 4:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/PS-bg.png" class="bg-img">');
                                break;
                            case 5:
                                $(this).find('img').after('<img src="<?php echo $main_url ; ?>img/PS_1-bg.png" class="bg-img">');
                                break;
                        }
                        });
                        $('#serviceSlider').on('beforeChange', function (slick, currentSlide, nextSlide) {
                            var get_index = currentSlide.currentSlide;
                            switch(get_index){
                                case 0:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 1:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 2:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 3:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 4:
                                    $(this).find('img.bg-img').remove();
                                    break;
                                case 5:
                                    $(this).find('img.bg-img').remove();
                                    break;
                            }                          
                        })
                        // $('#serviceSlider').parents('.pg').css('background-image','url(<?php echo $main_url ; ?>img/ss-bg.png)');
                        $('#serviceSlider').find('img').after('<img src="<?php echo $main_url ; ?>img/PS-bg.png" class="bg-img">');
                        // $('<img src="<?php echo $main_url ; ?>img/PS-bg.png" class="bg-img">').insertAfter('#serviceSlider img');
                    }
                })
    </script>