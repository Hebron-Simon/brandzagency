<!DOCTYPE html>

<html lang="en">

    <head>
        
    <title>Logos Web Design | Contact Us</title>   

    <?php include("inc/header.php"); ?>

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo $main_url ; ?>img/banner_testimonial.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="service-desc text-center">
                                    <h2>FEEL FREE TO CONTACT US</h2>
                                    <p>Have any questions about our services? We'd love to help you out anytime.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="testVideo">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-12 col-12">
                            <div class="contact-tab" data-aos="fade-up">
                                <div class="contact-info">
                                    <i class="sprite_1 sprite-phone-call"></i>
                                    <h5>Call Professional Consultants</h5>
                                    <p> You can call our professional consultants anytime, we're available around the clock for you assistance.</p>
                                    <a href="<?php echo$primary_phone_link;?>" class="btn btn-rounded btn-white-outline active btn-lg"><?php echo$primary_phone;?></a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-12 col-12">
                            <div class="contact-tab" data-aos="fade-down">
                                <div class="contact-info">
                                    <i class="sprite_1 sprite-chat"></i>
                                    <h5>Or Chat Live</h5>
                                    <p>
                                        We're also available on live chat service 24/7! Just ping us and we'll take care of it all.
                                    </p>
                                    <a href="<?php echo$chat_open?>" class="btn btn-rounded btn-white-outline active btn-lg chat">Talk With Us </a>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </section>
            <section class="contactForm pg" data-aos="zoom-out">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-10 col-12 mx-auto" data-form-type="contact_form">
                            <h2 class="title">LET US HELP YOU OUT</h2>
                            <p>Looking to expand your horizons? We're experts at just what you're looking for! Just help out our simple questionnaire.</p>
                            <form class="leadForm" method="post" enctype="multipart/form-data" action="javascript:void(0)">
                                 <!--hidden required values-->
                                    <input type="hidden" id="formType" name="formType">
                                    <input type="hidden" id="referer" name="referer">
                                <div class="form-group">
                                    <label for="name">Name <span>*</span></label>
                                    <input type="text" name="name" class="form-control" id="name" required>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="email">Email <span>*</span></label>
                                            <input type="email" name="email" class="form-control" id="email" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label for="phone">Phone Number <span>*</span></label>
                                            <input type="tel" maxlength="12" name="phone" class="form-control" id="phone" required>
                                        </div>
                                    </div>
                                </div>
                              
                                
                                <div class="form-group">
                                    <label for="comments">Additional Comments <span>*</span></label>
                                    <textarea class="form-control" name="customers_meta[company]" id="comments" required></textarea>
                                </div>
                                <div id="formResult"></div>
                                <div class="form-group">
                                    <button value="1" name="signupForm" type="submit" class="btn btn-rounded btn-white-outline active btn-lg">Submit </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
            <div class="pg connectGlobally" data-aos="fade-up">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="title">Connect with one of our global offices</h2>
                        </div>
                        <div class="col-md-6 p-0">
                            <div class="map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2482.375183285362!2d-0.08043148438519346!3d51.52467807963796!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761cb09120bcf9%3A0x6a26b46d69c2540!2s31%20New%20Inn%20Yard%2C%20Hackney%2C%20London%20EC2A%203EY%2C%20UK!5e0!3m2!1sen!2s!4v1602673824927!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                            </div>
                        </div>
                        <div class="col-md-6 p-0 bg-grey d-flex align-items-center">
                            <ul class="contactAdd">
                                <li>
                                    <h5>Headquarters</h5>
                                    <p><?php echo$primary_address;?></p>
                                </li>
                                <li>
                                    <h5>Phone</h5>
                                    <a href="<?php echo$primary_phone_link;?>"><?php echo$primary_phone;?></a>
                                </li>
                                <li>
                                    <h5>Email</h5>
                                    <a href="<?php echo$primary_email_link;?>"><?php echo$primary_email;?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    <?php include("inc/footer.php"); ?>

</html>