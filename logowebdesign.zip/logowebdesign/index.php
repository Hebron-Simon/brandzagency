
<!DOCTYPE html>
<html lang="en">
    <head>
    <?php include("inc/header.php"); ?>
    <?php include("inc/banner.php"); ?>
    <?php include("inc/about-us.php"); ?>
    <?php include("inc/projects.php"); ?>
    <?php include("inc/pricing.php"); ?>
    <?php include("inc/leading.php"); ?>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
</html>    