<!DOCTYPE html>

<html lang="en">

   <head>

    <title>Logos Web Design | Testimonials</title>   

    <?php include("inc/header.php"); ?>   

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo$main_url;?>img/banner_testimonial.jpg" alt="banner">
                </div>
                <div class="banner-content" data-aos="fade-up">
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="service-desc text-center">
                                    <h2>THIS IS WHAT INDUSTRY’S TOP CLIENTELE SOUNDS LIKE</h2>
                                    <p>We believe that the best marketing strategy is a satisfied customer.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="testVideo" data-aos="fade-up">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="testimonialDemo">
                                <div class="video">
                                    <img src="<?php echo$main_url;?>img/video1.jpg" alt="video">
                                </div>
                                <div class="videoContent">
                                    <a href="javascript:void(0);" class="unfillPlay">
                                        <i class="fa fa-play"></i>
                                    </a>
                                    <h5>Henrietta M. Thornton</h5>
                                    <p>“I am an entrepreneur. I own a store, a website and have been marketing my business to the fullest..."</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="testimonialDemo">
                                <div class="video">
                                    <img src="<?php echo$main_url;?>img/video2.jpg" alt="video">
                                </div>
                                <div class="videoContent">
                                    <a href="javascript:void(0);" class="unfillPlay">
                                        <i class="fa fa-play"></i>
                                    </a>
                                    <h5>Richard L. Kenyon</h5>
                                    <p>“Brandz Agency managed to professionally turn my entire brand image from bland and boring to one of the most visually appealing, captivating and ..."</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="comments pg" data-aos="fade-down">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/sg-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Outstanding services
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                    “Working with them was as effortless and easy as working with an old friend. They listen, understand and deliver.”
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        <h5 class="quoted">
                                        Angela D. Galasso
                                            <small>Local retailer.  </small>
                                        </h5>
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/hw-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Highly Applauded
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                    “Their animated logo services helped grow my branding within days. I had better sales to prospect ratio and better consumer reactions to advertising ventures. Thank you, Brandz Agency.”
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        <h5 class="quoted">
                                        Timothy Ross,
                                            <small>Entrepreneur. </small>
                                        </h5>
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/ms-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Well done!
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                    Working in the media marketing agency, I always recommend Brandz Agency to my clients for a better success rate of the entire marketing strategy and they never fail to deliver. Looking forward to work with them in the future.
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        
                                        <h5 class="quoted">
                                            Jonathan C
                                            <small>Media Marketing Agent.</small>
                                        </h5> 
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/tf-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Outstanding services
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                    I tried creating it with free online designing tools but wasn’t satisfied with the results. I’m loving my restaurant’s new logo. It is everything I asked for, professional services really speak for themselves. 
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        <h5 class="quoted">
                                        Anthony Henry,
                                            <small>Restaurant owner </small>
                                        </h5>
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/cslat-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Highly Applauded
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                    "My website couldn't have turned out any better. I like the entire user interface and aesthetic element of it. The sales are better than ever. They really work like trur professionals."
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        <h5 class="quoted">
                                            Abbie Rogers
                                            <small>Fashion retailer. </small>
                                        </h5>
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-12">
                            <div class="card">
                                <div class="card-header">
                                    <img src="<?php echo$main_url;?>img/etech-bw.png" alt="bw">
                                    <h5 class="quoted">
                                        Well done!
                                        <small>Overall Rating from 49 Users</small>
                                    </h5>
                                    <i class="sprite_1 sprite-rating"></i>
                                </div>
                                <div class="card-body">
                                    <p>
                                        "Their designing team helped me with my startup from the beginning and gave full support and maintenance until I reached my desired goals with my branding expectations. I can never thank them enough for their impeccable services.
                                    </p>
                                </div>
                                <div class="card-footer">
                                    <div class="commentBy">
                                        <h5 class="quoted">
                                            Gerald E. Beltz,
                                            <small>Entrepreneur. </small>
                                        </h5>
                                        <a href="javascript:void(0);" class="fillPlay">
                                            <i class="fa fa-play"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>


    <?php include("inc/footer.php"); ?>
    
    </html>