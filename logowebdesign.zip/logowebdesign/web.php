<!DOCTYPE html>

<html lang="en">

    <head>

    <title>Logos Web Design | Branding</title>   

    <?php include("inc/header.php"); ?>

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo$main_url;?>img/banner_web.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 col-12">
                                <div class="row d-none">
                                    <div class="col">
                                        <img src="<?php echo$main_url;?>img/seo-friendly.png" alt="responsive" class="w-auto">
                                    </div>
                                    <div class="col">
                                        <img src="<?php echo$main_url;?>img/customized.png" alt="responsive" class="w-auto">
                                    </div>
                                    <div class="col">
                                        <img src="<?php echo$main_url;?>img/responsive.png" alt="responsive" class="w-auto">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="service-desc">
                                            <h2>
                                                bring your vision to life with
                                                <span>a professional website</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h2>70% DISCOUNT</h2>
                                    </div>
                                    <div class="card-body">
                                        <h3>
                                            Let’s start your project,
                                            <strong>Drop us your details!</strong>
                                        </h3>
                                        <div data-form-type="signup_form">
                                            <form method="post" enctype="multipart/form-data" action="javascript:void(0)" class="leadForm">
                                                <!--hidden required values-->
                                                <input type="hidden" id="formType" name="formType">
                                                <input type="hidden" id="referer" name="referer">
                                                <div class="form-group">
                                                    <label for="name" class="d-none">Name</label>
                                                    <input type="text" name="name" required  class="form-control btn-rounded" id="name" placeholder="Your Name">
                                                </div>
                                                <div class="form-group">
                                                    <label for="email" class="d-none">email</label>
                                                    <input type="email" name="email" required class="form-control btn-rounded" id="email" placeholder="Email Address">
                                                </div>
                                                <div class="form-group">
                                                    <label for="number" class="d-none">phone</label>
                                                    <input type="tel" name="phone" required class="form-control btn-rounded" maxlength="12" id="phone" placeholder="Phone Number">
                                                </div>
                                                <div id="formResult"></div>
                                                <div class="form-group">
                                                    <button name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
                                                </div>
                                            </form>
                                        </div>                                        <p>
                                            *Our Design Consultant will call you to confirm your package
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div id="exTab1">	
                <div class="middle-nav">
                        <ul class="nav nav-pills">
                            <li class="active">
                                <a  href="#1a" class="active" data-toggle="tab">web design</a>
                            </li>
                            <li>
                                <a href="#2a" data-toggle="tab">web package</a>
                            </li>
                            <li>
                                <a href="#3a" data-toggle="tab">web Process</a>
                            </li>
                            <li>
                                <a href="#4a" data-toggle="tab">faqs</a>
                            </li>
                        </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <section class="pg whyUs" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 bg-grey">
                                            <h2 class="title">why us?</h2>
                                            <div class="why-content">
                                                <div class="col-md-6">
                                                    <img src="<?php echo$main_url;?>img/whyUs.jpg" alt="whyUs">
                                                </div>
                                                <div class="col-md-6">
                                                    <h3>We simply are better than our competitors. Experienced and award-winning at our job.</h3>
                                                    <p>
                                                        Go digital like a pro with a high-quality and professionally developed website that is guaranteed to drive traffic, increase your leads to conversion rates and digital visibility. We are eqaully efficient in open source CMS like WordPress and Drupal. 
                                                    </p>
                                                    <ul class="whyList">
                                                        <li>
                                                            <i class="sprite sprite-y1"></i>
                                                            <h6>Quick Turnaround Time</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y2 mt-2"></i>
                                                            <h6>Cost-effective Designers</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y3"></i>
                                                            <h6>Award-winning Desgin</h6>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                
                            </section>
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">2D Animations</li>
                                                <li class="tab-link" data-tab="tab-3">3D Animations</li>
                                                <li class="tab-link" data-tab="tab-4">Whiteboard Animations </li>
                                                <li class="tab-link" data-tab="tab-5">Typographic</li>
                                                <li class="tab-link" data-tab="tab-6">Explainer Videos </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li class="first"><a href="<?php echo$main_url;?>img/vd1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/vd9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                <li class="last"><a href="<?php echo$main_url;?>img/vd10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>  
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>  
                                        <div class="tab-content" id="tab-5">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-6">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/vd1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/vd10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>                                       
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox">lets get started</a></li>
                                                <li><a href="<?php echo$chat_open;?>" class="btn btn-rounded btn-white-outline active chat btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-down">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Simpler Solutions. Quicker Results.</h2>
                                                    <p>Our Websites are designed in accordance to your industry trends</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>CUSTOM WEBSITE</h3>
                                                        <p>
                                                            Want to add your sales & marketing strategies in a dynamic website
                                                            that keeps your customers engaged? Our web design and development
                                                            team is experienced and skilled to get the job done. Websites from Designs
                                                            Avenue don't need to be developed separately for mobiles & tablets, we
                                                            make them mobile-friendly and efficient taking care of every element.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Customized</li>
                                                            <li>Engaging</li>
                                                            <li>Mobile-friendly</li>
                                                            <li>High user satisfaction rate and maximum ROI.</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/CW.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>STATIC WEBSITE DESIGN</h3>
                                                        <p>
                                                            As opposed to dynamic websites, static websites serve completely different
                                                            purpose and have completely different nature of front and backend
                                                            development. They are great for providing necessary information to your 
                                                            visitors in a pleasing and neat layout for maximum customer retention.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Visually Aesthetic Layout</li>
                                                            <li>User-friendly</li>
                                                            <li>Responsive</li>
                                                            <li>Easier management</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/CSW.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>CMS – Websites</h3>
                                                        <p>
                                                            A strong Content Management System is an essential requirement
                                                            for each & every business these days. CMS is a great digital tool for
                                                            maintaining relevance and the accuracy of your business information. 
                                                            We provide development solutions for custom CMS or popular
                                                            CMS platforms like WordPress, Joomla and Drupal.  
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Strategy Driven</li>
                                                            <li>Responsive</li>
                                                            <li>Easier Management</li>
                                                            <li>Positive UX</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/CMS.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>E-commerce Websites</h3>
                                                        <p>
                                                            Well-crafted design and development of an E-commerce website works as a fuel for every business. What makes an E-commerce website successful depends upon its relevant industry and target audience. It requires an expert to provide relevant information, user comfort, brand enhancement and visibility of text to create a user-friendly site.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>B2B E-commerce Website</li>
                                                            <li>B2C E-commerce Website</li>
                                                            <li>C2B E-commerce Website</li>
                                                            <li>C2C E-commerce Website</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/CMS.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">Looking for a creative website </h2>
                                            <p>That converses your brand personality? We create custom websites that raise appeal and brand.  </p>
                                            <ul class="creativity">
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/revision.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/revision.png" alt="quote">
                                                        </i>
                                                        <p>Unlimited Revisions</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/ownership.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/ownership.png" alt="quote">
                                                        </i>
                                                        <p>100% Ownership Rights</p>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="quote" style="background-image: url('<?php echo$main_url;?>img/moneyBack.png');">
                                                        <i>
                                                            <img src="<?php echo$main_url;?>img/moneyBack.png" alt="quote">
                                                        </i>
                                                        <p>100% Money Back Guarantee</p>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pg packages" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <h2 class="title">REASONABLE DESIGN PACKAGES</h2>
                                            <p>We have reasonably tailored packages suitable for your requirements and budget so we have something for everyone.</p>
                                            <div id="exTab2">
                                                <ul class="nav nav-tabs tab-pill" role="tablist">
                                                    <li class="active">
                                                        <a data-toggle="tab" href="#tabWebCorporate" role="tab">Website Corporate</a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tabWebEcom" role="tab">Website E-commerce</a>
                                                    </li>
                                                    <li>
                                                        <a data-toggle="tab" href="#tabWebCombo" role="tab">Website Combo</a>
                                                    </li>
                                                </ul>
                                                <div class="tab-content clearfix">
                                                <div id="tabWebCorporate" class="tab-pane fade active show in" role="tabpanel" aria-labelledby="tabWebCorporate">
                                                    <div class="packageList tab-packageSlider owl-carousel owl-theme">
                                                    <div class="item"><div data-package-box class="pricing-box  ">
                                                        <div class="productSku" style="display: none;">WEB_BUSSINESS_BASIC    </div>
                                                        <div>
                                                        <div class="card">
                                                            <div class="card-header">
                                                                <p class="bestSeller">Business (Basic)</p>
<!--                                                                      <h4>--><?//= $short_description ?><!--</h4>-->
                                                                <div class="price">
                                                                     <h2><span>£</span>249</h2>
                                                                    <h3><span>£830</span></h3>
                                                                </div>
                                                            </div>
                                                            <div class="card-body">
                                                                <div class="scroll" data-package-scroll>
                                                                  <ul>
                                                                    <li>3 Page Business Website</li>
                                                                    <li>5 Revisions</li>
                                                                    <li>Complete Deployment</li>
                                                                    <li>Dedicated Designer </li>
                                                                    <li>Dedicated Professional Developer </li>
                                                                    <li>Dedicated Account Manager</li>
                                                                    <li>2 Stock Images</li>
                                                                    <li>Complete W3C Certified HTML</li>
                                                                    <li>Google Optimised Sitemap</li>
                                                                    <li>48 to 72 hours TAT</li>
                                                                    <li>Features:</li>
                                                                    <li>100% Ownership Rights</li>
                                                                    <li>100% Satisfaction Guaranteed</li>
                                                                    <li>100% Unique Design Guarantee</li>
                                                                    <li>100% Money Back Guarantee</li>
                                                                    <li>All Final File Formats</li>
                                                                    <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                    </ul>                                            
                                                                </div>
                                                            </div>
                                                            <div class="card-footer">
                                                                <ul class="list-center">
                                                                    <li>
                                                                        <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_BASIC"
                                                                        data-promotion-id="0"
                                                                        data-price="249"
                                                                        data-price-text="£249"
                                                                        data-title="Business (Basic)"
                                                                        data-package-id="755">Order now</button>
                                                                    </li>
                                                                    <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                    <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                    <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>                                                                        
                                            </div>
                                            <div class="item">
                                                <div data-package-box class="pricing-box  ">
                                                    <div class="productSku" style="display: none;">WEB_BUSSINESS_PLUS    </div>
                                                        <div>
                                                            <div class="card">
                                                                <div class="card-header">
                                                                    <p class="bestSeller">Business Plus</p>
<!--                                                                          <h4>--><?//= $short_description ?><!--</h4>-->
                                                                    <div class="price">
                                                                         <h2><span>£</span>309</h2>
                                                                        <h3><span>£1030</span></h3>
                                                                    </div>
                                                                </div>
                                                                <div class="card-body">
                                                                    <div class="scroll" data-package-scroll>
                                                                      <ul>
                                                                        <li>5 Unique Business Pages Website</li>
                                                                        <li>Unlimited Revisions</li>
                                                                        <li>Complete Deployment</li>
                                                                        <li>2 Dedicated Designer </li>
                                                                        <li>Dedicated Professional Developer </li>
                                                                        <li>Dedicated Account Manager</li>
                                                                        <li>3 Stock Images</li>
                                                                        <li>Complete W3C Certified HTML</li>
                                                                        <li>Google Optimised Sitemap</li>
                                                                        <li>48 to 72 hours TAT</li>
                                                                        <li>Features:</li>
                                                                        <li>100% Ownership Rights</li>
                                                                        <li>100% Satisfaction Guaranteed</li>
                                                                        <li>100% Unique Design Guarantee</li>
                                                                        <li>100% Money Back Guarantee</li>
                                                                        <li>Add-Ons:</li>
                                                                        <li>Mobile Responsive will be charged additionally</li>
                                                                        <li>CMS will be Charged Additionally</li>
                                                                        <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                        </ul>                                            
                                                                    </div>
                                                                    </div>
                                                                    <div class="card-footer">
                                                                        <ul class="list-center">
                                                                            <li>
                                                                                <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_PLUS"
                                                                                data-promotion-id="0"
                                                                                data-price="309"
                                                                                data-price-text="£309"
                                                                                data-title="Business Plus"
                                                                                data-package-id="756">Order now</button>
                                                                            </li>
                                                                            <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                            <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                            <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                                        
                                                    </div>
                                                    <div class="item">
                                                        <div data-package-box class="pricing-box  popular">
                                                            <div class="productSku" style="display: none;">WEB_BUSSINESS_PRIME    </div>
                                                            <div>
                                                                <div class="card">
                                                                    <div class="card-header">
                                                                        <p class="bestSeller">Business Prime</p>
<!--                                                                                 <h4>--><?//= $short_description ?><!--</h4>-->
                                                                        <div class="price">
                                                                             <h2><span>£</span>529</h2>
                                                                            <h3><span>£1763</span>70% OFF</h3>
                                                                        </div>
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="scroll" data-package-scroll>
                                                                            <ul>
                                                                                <li>10 Unique Business Pages Website</li>
                                                                                <li>Unlimited Revisions</li>
                                                                                <li>Complete Deployment</li>
                                                                                <li>4 Dedicated Designer </li>
                                                                                <li>Dedicated Professional Developer </li>
                                                                                <li>Dedicated Account Manager</li>
                                                                                <li>5 Stock Images</li>
                                                                                <li>Complete W3C Certified HTML</li>
                                                                                <li>Google Optimised Sitemap</li>
                                                                                <li>48 to 72 hours TAT</li>  
                                                                                <li>Features:</li>
                                                                                <li>100% Ownership Rights</li>
                                                                                <li>100% Satisfaction Guaranteed</li>
                                                                                <li>100% Unique Design Guarantee</li>
                                                                                <li>100% Money Back Guarantee</li>
                                                                                <li>All Final File Formats</li>
                                                                                <li>Add-Ons:</li>
                                                                                <li>Mobile Responsive will be charged additionally</li>
                                                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                                </ul>                                            
                                                                            </div>
                                                                        </div>
                                                                            <div class="card-footer">
                                                                                <ul class="list-center">
                                                                                    <li>
                                                                                      <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_BUSSINESS_PRIME"
                                                                                      data-promotion-id="0"
                                                                                      data-price="529"
                                                                                      data-price-text="£529"
                                                                                      data-title="Business Prime"
                                                                                      data-package-id="757">Order now</button>
                                                                                    </li>
                                                                                    <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                                    <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                                    <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>                                                                        
                                                            </div>                                                                                                                                                                                        
                                                        </div>
                                            </div>
                                            <div id="tabWebEcom" class="tab-pane fade" role="tabpanel" aria-labelledby="tabWebEcom">
                                                <div class="packageList tab-packageSlider owl-carousel owl-theme">
                                                    <div class="item">
                                                        <div data-package-box class="pricing-box  ">
                                                            <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_BASIC    </div>
                                                            <div>
                                                                <div class="card">
                                                                    <div class="card-header">
                                                                        <p class="bestSeller">E-Commerce Basic</p>
<!--                                                                              <h4>--><?//= $short_description ?><!--</h4>-->
                                                                        <div class="price">
                                                                             <h2><span>£</span>749</h2>
                                                                            <h3><span>£2496</span></h3>
                                                                        </div>
                                                                    </div>
                                                                    <div class="card-body">
                                                                        <div class="scroll" data-package-scroll>
                                                                          <ul>
                                                                            <li>Upto 100 Unique Business Pages </li>
                                                                            <li>Product Detail Page Design</li>
                                                                            <li>Content Management System</li>
                                                                            <li>Shopping Cart Integration</li>
                                                                            <li>Product Rating & Reviews</li>
                                                                            <li>Easy Product Search</li>
                                                                            <li>Payment Gateway Integration</li>
                                                                            <li>Multi-currency Support</li>
                                                                            <li>Shipping Module Integration</li>
                                                                            <li>Express Check-out Option</li>
                                                                            <li>Pre-defined Tax Calculation</li>
                                                                            <li>Customer Account Area</li>
                                                                            <li>Complete Deployment</li>
                                                                            <li>Social Media Plugins</li>
                                                                            <li>Easy Order & Product Management</li>
                                                                            <li>Dedicated Account Manager</li>
                                                                            <li>Features:</li>
                                                                            <li>100% Ownership Rights</li>
                                                                            <li>100% Satisfaction Guaranteed</li>
                                                                            <li>100% Unique Design Guarantee</li>
                                                                            <li>100% Money Back Guarantee</li>
                                                                            <li>All Final File Formats</li>
                                                                            <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                            </ul>                                            
                                                                        </div>
                                                                    </div>
                                                                    <div class="card-footer">
                                                                        <ul class="list-center">
                                                                            <li>
                                                                                <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_BASIC"
                                                                                data-promotion-id="0"
                                                                                data-price="749"
                                                                                data-price-text="£749"
                                                                                data-title="E-Commerce Basic"
                                                                                data-package-id="758">Order now</button>
                                                                            </li>
                                                                            <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                            <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                            <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                                        
                                                    </div>                                                                                                                                                
                                                    <div class="item">
                                                        <div data-package-box class="pricing-box  ">
                                                            <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_PLUS </div>
                                                            <div>
                                                              <div class="card">
                                                                  <div class="card-header">
                                                                      <p class="bestSeller">E-Commerce Plus</p>
<!--                                                                            <h4>--><?//= $short_description ?><!--</h4>-->
                                                                      <div class="price">
                                                                           <h2><span>£</span>929</h2>
                                                                          <h3><span>£3096</span></h3>
                                                                      </div>
                                                                  </div>
                                                                  <div class="card-body">
                                                                      <div class="scroll" data-package-scroll>
                                                                        <ul>
                                                                            <li>Unlimited Products</li>
                                                                            <li>Unlimited Revisions</li>
                                                                            <li>Unique Banner Slider</li>
                                                                            <li>Complete Deployment</li>
                                                                            <li>4 Dedicated designer</li>
                                                                            <li>2 Dedicated Professional Developer</li>
                                                                            <li>Dedicated Account Manager</li>
                                                                            <li>Complete W3C Certified HTML</li>
                                                                            <li>Product Rating & Reviews</li>
                                                                            <li>Easy Product Search</li>
                                                                            <li>Payment Gateway Integration</li>
                                                                            <li>Google Optimised Sitemap</li>
                                                                            <li>CMS / Admin Panel Support</li>
                                                                            <li>Conceptual and Dynamic Website</li>
                                                                            <li>Fully Mobile Responsive</li>
                                                                            <li>Online Payment Integration (Optional)</li>
                                                                            <li>Social Media Plugins</li>
                                                                            <li>Features:</li>
                                                                            <li>100% Ownership Rights</li>
                                                                            <li>100% Satisfaction Guarantee</li>
                                                                            <li>100% Unique Design Guarantee</li>
                                                                            <li>100% Money Back Guarantee</li>
                                                                            <li>All Final File Formats</li>
                                                                            <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                            </ul>                                           
                                                                        </div>
                                                                    </div>
                                                                    <div class="card-footer">
                                                                        <ul class="list-center">
                                                                            <li>
                                                                              <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_PLUS"
                                                                              data-promotion-id="0"
                                                                              data-price="929"
                                                                              data-price-text="£929"
                                                                              data-title="E-Commerce Plus"
                                                                              data-package-id="759">Order now</button>
                                                                            </li>
                                                                            <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                            <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                            <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>                                                                      
                                                    </div>                                                                                                                                                   
                                                    <div class="item">
                                                        <div data-package-box class="pricing-box  popular">
                                                            <div class="productSku" style="display: none;">WEB_ECOMMERCE_E_COMMERCE_PRIME    </div>
                                                             <div>
                                                                 <div class="card">
                                                                     <div class="card-header">
                                                                         <p class="bestSeller">E-Commerce Prime</p>
<!--                                                                         <h4>--><?//= $short_description ?><!--</h4>-->
                                                                         <div class="price">
                                                                             <h2><span>£</span>1299</h2>
                                                                             <h3><span>£4330</span>70% OFF</h3>
                                                                         </div>
                                                                     </div>
                                                                     <div class="card-body">
                                                                         <div class="scroll" data-package-scroll>
                                                                           <ul>
                                                                                <li>Unlimited Products</li>
                                                                                <li>Unlimited Revisions</li>
                                                                                <li>Complete Deployment</li>
                                                                                <li>6 Dedicated Designer</li>
                                                                                <li>2 Dedicated Professional Developer</li>
                                                                                <li>Dedicated Account Manager</li>
                                                                                <li>Complete W3C Certified HTML</li>
                                                                                <li>Google Optimised Sitemap</li>
                                                                                <li>Unlimited Products</li>
                                                                                <li>CMS / Admin Panel Support</li>
                                                                                <li>Full Shopping Cart Integration</li>
                                                                                <li>Payment Module Integration</li>
                                                                                <li>Easy Product Search</li>
                                                                                <li>Product Reviews</li>
                                                                                <li>Order Management</li>
                                                                                <li>Fully Mobile Responsive</li>
                                                                                <li>Product Detail Page Design</li>
                                                                                <li>Unlimited Categories</li>
                                                                                <li>Product Rating & Reviews</li>
                                                                                <li>Payment Gateway Integration</li>
                                                                                <li>Multi-currency Support</li>
                                                                                <li>Cutomer Log-in Area</li>
                                                                                <li>Free Stationery Design:</li>
                                                                                <li>5 Social Media Platform Covers</li>
                                                                                <li>Bi-Fold Brochure (OR) 2 Sided Flyer Design</li>
                                                                                <li>Invoice Design</li>
                                                                                <li>Email Signature</li>
                                                                                <li>Features:</li>
                                                                                <li>100% Ownership Rights</li>
                                                                                <li>100% Satisfaction Guarantee</li>
                                                                                <li>100% Unique Design Guarantee</li>
                                                                                <li>100% Money Back Guarantee</li>
                                                                                <li>All Final File Formats</li>
                                                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                                </ul>                                            
                                                                        </div>
                                                                        </div>
                                                                        <div class="card-footer">
                                                                            <ul class="list-center">
                                                                                <li>
                                                                                  <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_ECOMMERCE_E_COMMERCE_PRIME"
                                                                                  data-promotion-id="0"
                                                                                  data-price="1299"
                                                                                  data-price-text="£1299"
                                                                                  data-title="E-Commerce Prime"
                                                                                  data-package-id="760">Order now</button>
                                                                                </li>
                                                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                            </ul>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>                                                                        
                                                        </div>
                                                    </div>
                                                    </div>
                                                    <div id="tabWebCombo" class="tab-pane fade" role="tabpanel" aria-labelledby="tabWebCombo">
                                                        <div class="packageList tab-packageSlider owl-carousel owl-theme">
                                                            <div>
                                                                <div data-package-box class="pricing-box  ">
                                                                    <div class="productSku" style="display: none;">WEB_COMBO_STARTER_COMBO    </div>
                                                                        <div>
                                                                            <div class="card">
                                                                                <div class="card-header">
                                                                                    <p class="bestSeller">Starter Combo</p>
<!--                                                                                         <h4>--><?//= $short_description ?><!--</h4>-->
                                                                                    <div class="price">
                                                                                        <h2><span>£</span>1099</h2>
                                                                                        <h3><span>£3663</span></h3>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="card-body">
                                                                                    <div class="scroll" data-package-scroll>
                                                                                    <ul>
                                                                                        <li>Upto 15 Unique Pages Website</li>
                                                                                        <li>Conceptual and Dynamic Website</li>
                                                                                        <li>Content Management System (CMS)</li>
                                                                                        <li>Mobile Responsive</li>
                                                                                        <li>Easy Product Search</li>
                                                                                        <li>Product Reviews</li>
                                                                                        <li>Unlimited Products</li>
                                                                                        <li>Unlimited Categories</li>
                                                                                        <li>Promotional Product Showcase</li>
                                                                                        <li>New Product Showcase</li>
                                                                                        <li>Full Shopping Cart Integration</li>
                                                                                        <li>Payment Module Integration</li>
                                                                                        <li>Sales & Inventory Management</li>
                                                                                        <li>JQuery Slider</li>
                                                                                        <li>3 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                                                        <li>FREE Google Friendly Sitemap</li>
                                                                                        <li>Custom Email Address</li>
                                                                                        <li>Complete W3C Certified HTML</li>
                                                                                        <li>Features:</li>
                                                                                        <li>100% Ownership Rights</li>
                                                                                        <li>100% Satisfaction Guarantee</li>
                                                                                        <li>100% Unique Design Guarantee</li>
                                                                                        <li>100% Money Back Guarantee</li>
                                                                                        <li>All Final File Formats</li>
                                                                                        <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                                        </ul>                                            
                                                                                    </div>
                                                                                </div>
                                                                                <div class="card-footer">
                                                                                    <ul class="list-center">
                                                                                        <li>
                                                                                            <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_STARTER_COMBO"
                                                                                            data-promotion-id="0"
                                                                                            data-price="1099"
                                                                                            data-price-text="£1099"
                                                                                            data-title="Starter Combo"
                                                                                            data-package-id="761">Order now</button>
                                                                                        </li>
                                                                                        <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                                        <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                                        <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>                                                                        
                                                                </div>
                                                                <div>
                                                                    <div data-package-box class="pricing-box  ">
                                                                        <div class="productSku" style="display: none;">WEB_COMBO_BUSINESS_COMBO    </div>
                                                                        <div>
                                                                            <div class="card">
                                                                                <div class="card-header">
                                                                                    <p class="bestSeller">Business Combo</p>
<!--                                                                                    <h4>--><?//= $short_description ?><!--</h4>-->
                                                                                    <div class="price">
                                                                                        <h2><span>£</span>1599</h2>
                                                                                        <h3><span>£5330</span></h3>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="card-body">
                                                                                    <div class="scroll" data-package-scroll>
                                                                                      <ul>
                                                                                            <li>Upto 15 Unique Pages Website</li>
                                                                                            <li>Conceptual and Dynamic Website</li>
                                                                                            <li>Content Management System (CMS)</li>
                                                                                            <li>Mobile Responsive</li>
                                                                                            <li>Online Reservation/Appointment Tool (Optional)</li>
                                                                                            <li>Online Payment Integration (Optional)</li>
                                                                                            <li>Custom Forms</li>
                                                                                            <li>Lead Capturing Forms (Optional)</li>
                                                                                            <li>Striking Hoover Effects</li>
                                                                                            <li>Newsfeed Integration</li>
                                                                                            <li>Social Media Integration</li>
                                                                                            <li>15 Stock images</li>
                                                                                            <li>JQuery Slider</li>
                                                                                            <li>4 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                                                            <li>FREE Google Friendly Sitemap</li>
                                                                                            <li>Custom Email Address</li>
                                                                                            <li>Complete W3C Certified HTML</li>
                                                                                            <li>Features:</li>
                                                                                            <li>100% Ownership Rights</li>
                                                                                            <li>100% Satisfaction Guarantee</li>
                                                                                            <li>100% Unique Design Guarantee</li>
                                                                                            <li>100% Money Back Guarantee</li>
                                                                                            <li>All Final File Formats</li>
                                                                                            <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                                            </ul>                                            
                                                                                        </div>
                                                                                     </div>
                                                                                     <div class="card-footer">
                                                                                         <ul class="list-center">
                                                                                             <li>
                                                                                               <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_BUSINESS_COMBO"
                                                                                               data-promotion-id="0"
                                                                                               data-price="1599"
                                                                                               data-price-text="£1599"
                                                                                               data-title="Business Combo"
                                                                                               data-package-id="762">Order now</button>
                                                                                             </li>
                                                                                             <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                                             <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                                             <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                                         </ul>
                                                                                     </div>
                                                                                 </div>
                                                                             </div>
                                                                            </div>                                                                        
                                                                        </div>
                                                                        <div>
                                                                            <div data-package-box class="pricing-box  popular">
                                                                                <div class="productSku" style="display: none;">WEB_COMBO_ULTIMATE_COMBO    </div>
                                                                                 <div>
                                                                                     <div class="card">
                                                                                         <div class="card-header">
                                                                                             <p class="bestSeller">Ultimate Combo</p>
<!--                                                                                             <h4>--><?//= $short_description ?><!--</h4>-->
                                                                                             <div class="price">
                                                                                                 <h2><span>£</span>2099</h2>
                                                                                                 <h3><span>£6996</span>70% OFF</h3>
                                                                                             </div>
                                                                                         </div>
                                                                                         <div class="card-body">
                                                                                             <div class="scroll" data-package-scroll>
                                                                                               <ul>
                                                                                                <li>Unlimited Page Website</li>
                                                                                                <li>Custom Content Management System (CMS)</li>
                                                                                                <li>Unique Pages and UI Design</li>
                                                                                                <li>Complete Custom Development</li>
                                                                                                <li>Process Automation Tools</li>
                                                                                                <li>Newsfeed Integration</li>
                                                                                                <li>Social Media Plugins Integration</li>
                                                                                                <li>Upto 20 Stock images</li>
                                                                                                <li>JQuery Slider</li>
                                                                                                <li>FREE Google Friendly Sitemap</li>
                                                                                                <li>Custom Email Address</li>
                                                                                                <li>5 Social Media Channels (Facebook, Twitter, Instagram)</li>
                                                                                                <li>Complete W3C Certified HTML</li>
                                                                                                <li>Features:</li>
                                                                                                <li>100% Ownership Rights</li>
                                                                                                <li>100% Satisfaction Guarantee</li>
                                                                                                <li>100% Unique Design Guarantee</li>
                                                                                                <li>100% Money Back Guarantee</li>
                                                                                                <li>All Final File Formats</li>
                                                                                                <li>Free Rush Delivery - Get Initial Concepts within 24 hours</li>
                                                                                                </ul>                                            
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="card-footer">
                                                                                            <ul class="list-center">
                                                                                                <li>
                                                                                                <button class="btn btn-rounded btn-white-outline active btn-sm order-package"  data-sku="WEB_COMBO_ULTIMATE_COMBO"
                                                                                                data-promotion-id="0"
                                                                                                data-price="2099"
                                                                                                data-price-text="£2099"
                                                                                                data-title="Ultimate Combo"
                                                                                                data-package-id="763">Order now</button>
                                                                                                </li>
                                                                                                <li><a href="<?php echo$main_url;?>packages.php" class="btn btn-rounded btn-black btn-sm allPack">see all packages</a></li>
                                                                                                <li><a href="<?php echo$chat_open;?>" class="chat"><i class="sprite sprite-f-msg"></i> Talk To us</a></li>
                                                                                                <li><a href="<?php echo$primary_phone_link;?>"><i class="sprite sprite-f-call"></i><?php echo$primary_phone;?></a></li>
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>                                                                        
                                                                        </div>
                                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h4>Key Features</h4>
                                            <ul class="list-center satisfaction text-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sG"></i>
                                                    <p>100% Satisfaction Guaranteed</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-cS"></i>
                                                    <p>24 X 7 Customer Support</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-oR"></i>
                                                    <p>100% Ownership Rights</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-mBG"></i>
                                                    <p>Money Back Guarantee</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-iSD"></i>
                                                    <p>Industry Specific Designers</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                            <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>Initial <br>Designs</h4>
                                                    <p>You get the initial mockups and designs files of your website within days of confirming your order</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR"></i>
                                                    <h4>Backend <br>Development</h4>
                                                    <p>After you're satisfied with the initial designs, our developers get started on the development of your website.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-oO"></i>
                                                    <h4>Unlimited<br>Revision</h4>
                                                    <p>In case of any dissatisfaction or final additions, you get free and unlimited revisions to make sure fluent final delivery.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Final <br>Delivery</h4>
                                                    <p>Your website is all set and ready to go. We run your website through multiple sessions of Q/A for no chance of any buigs or errors.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="4a">
                            <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li class="first">
                                                    <h4>Do I own my website?</h4>
                                                    <p>Yes. Once you pay for you project, you get the complete ownership of your website, including the content, codes and source files. You own everything.
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>Can I resell or revamp my website?</h4>
                                                    <p>Once the project is yours, you have complete authority to do as you please.</p>
                                                </li>
                                                <li>
                                                    <h4>Do I have to provide the hosting server for my website?</h4>
                                                    <p>It depends on the package you have selected.</p>
                                                </li>
                                                <li>
                                                    <h4>Do you provide content writing services?</h4>
                                                    <p>Yes. If you need professional and SEO friendly content for your website, you've come to the right place.</p>
                                                </li>
                                                <li class="last">
                                                    <h4>How long does it take to get my website running?</h4>
                                                    <p>Depends on the nature of your website but usually it takes our experts around 2 to 3 weeks.</p>
                                                </li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
</main>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
</html>   