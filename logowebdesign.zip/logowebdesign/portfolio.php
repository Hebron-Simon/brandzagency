<!DOCTYPE html>

<html lang="en">

   <head>

    <title>Logos Web Design | Portfolio</title>   

    <?php include("inc/header.php"); ?> 
    <section class="banner">
        <div class="banner-img">
            <img src="<?php echo$main_url;?>img/portfolio-banner.jpg" alt="banner">
        </div>
        <div class="banner-content no-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="row">
                            <div class="col-12">
                                <div class="service-desc">
                                    <h2>
                                        Our Portfolio
                                    </h2>
                                    <p>
                                    Whatever we do, we simply aim to take it above average. Our portfolio displays some of our successful projects over the years.
                                    </p>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-12"></div>
                </div>
            </div>
        </div>
    </section> 
    <?php include("inc/projects.php"); ?>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
    
    </html>