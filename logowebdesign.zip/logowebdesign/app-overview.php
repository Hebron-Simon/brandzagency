<!DOCTYPE html>

<html lang="en">

    <head>

    <title>Logos Web Design | Mobile App</title>   

    <?php include("inc/header.php"); ?>

    <main>
            <section class="banner">
                <div class="banner-img">
                    <img src="<?php echo$main_url;?>img/banner-app.jpg" alt="banner">
                </div>
                <div class="banner-content">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-7 col-12">
                                <div class="row d-none">
                                    <div class="col" data-aos="fade-up">
                                        <div class="service IS">
                                            <i class="sprite sprite-ban1"></i>
                                            <p>Industry-specific</p>
                                        </div>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <div class="service resp">
                                            <i class="sprite sprite-ban2"></i>
                                            <p>Responsive</p>
                                        </div>
                                    </div>
                                    <div class="col" data-aos="fade-up">
                                        <div class="service uiux">
                                            <i class="sprite sprite-ban3"></i>
                                            <p>UX/UI Friendly</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="service-desc" data-aos="fade-left">
                                            <h2>
                                                ACE THE BRANDING RACE
                                                <span>WITH A PRO MOBILE APP</span>
                                            </h2>
                                            <button class="btn btn-rounded btn-white-outline">Upto 70% off on all packages!</button>
                                            <div class="col-12 col-md-6 p-0">
                                                <a href="javascript:void(0);" class="btn btn-rounded btn-black popupBox d-lg-none d-block" data-toggle="modal" data-target="getQuote">lets get started</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-5 col-12">
                                <div class="card" data-aos="fade-down">
                                    <div class="card-header">
                                        <h2>70% DISCOUNT</h2>
                                    </div>
                                    <div class="card-body">
                                        <h3>
                                            Let’s start your project,
                                            <strong>Drop us your details!</strong>
                                        </h3>
                                        <div data-form-type="signup_form">
                                                <form method="post" enctype="multipart/form-data" action="javascript:void(0)" class="leadForm">
                                                    <!--hidden required values-->
                                                    <input type="hidden" id="formType" name="formType">
                                                    <input type="hidden" id="referer" name="referer">
                                                    <div class="form-group">
                                                        <label for="name" class="d-none">Name</label>
                                                        <input type="text" name="name" required  class="form-control btn-rounded" id="name" placeholder="Your Name">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="email" class="d-none">email</label>
                                                        <input type="email" name="email" required class="form-control btn-rounded" id="email" placeholder="Email Address">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="number" class="d-none">phone</label>
                                                        <input type="tel" name="phone" required class="form-control btn-rounded" maxlength="12" id="phone" placeholder="Phone Number">
                                                    </div>
                                                    <div id="formResult"></div>
                                                    <div class="form-group">
                                                        <button name="signupForm" type="submit" class="btn btn-rounded btn-yellow btn-block">Submit your Request</button>
                                                    </div>
                                                </form>
                                            </div>                                        
                                            <p>*Our Design Consultant will call you to confirm your package</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div id="exTab1">	
                <div class="middle-nav">
                    <ul class="nav nav-pills">
                        <li class="active">
                            <a  href="#1a" class="active" data-toggle="tab">app design</a>
                        </li>
                        <li>
                            <a href="#2a" data-toggle="tab">app process</a>
                        </li>
                        <li>
                            <a href="#3a" data-toggle="tab">faqs</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content clearfix">
                    <div class="tab-pane active" id="1a">
                            <section class="pg whyUs" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 bg-grey">
                                            <h2 class="title">why us?</h2>
                                            <div class="why-content">
                                                <div class="col-md-6">
                                                    <img src="<?php echo$main_url;?>img/whyUs.jpg" alt="whyUs">
                                                </div>
                                                <div class="col-md-6">
                                                    <h3>Mobile Applications offer wider reach and accessibility to your audience.</h3>
                                                    <p>
                                                        But with every other business with a mobile app these days, it is not enough to just participate but to excel at the art of consumer retention thorugh mobile technology. Logos Web Design know how to optimize your apps for maximum return on your investment.
                                                    </p>
                                                    <ul class="whyList">
                                                        <li>
                                                            <i class="sprite sprite-y1"></i>
                                                            <h6>Quick Turnaround Time</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y2 mt-2"></i>
                                                            <h6>Cost-effective Designers</h6>
                                                        </li>
                                                        <li>
                                                            <i class="sprite sprite-y3"></i>
                                                            <h6>Award-winning Desgin</h6>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                
                            </section>
                            <section class="pg glimpse" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <h2 class="title">A Glimpse Of Our Works</h2>
                                            <p>What we do is simply far superior than others</p>
                                            <ul class="tabs d-none" id="glimpse">
                                                <li class="tab-link current" data-tab="tab-1">All</li>
                                                <li class="tab-link" data-tab="tab-2">Android</li>
                                                <li class="tab-link" data-tab="tab-3">iOS</li>
                                                <li class="tab-link" data-tab="tab-4">Native React</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="container-fluid">
                                    <div class="row">
                                        <div class="tab-content current" id="tab-1">
                                            <div class="workGal">
                                            <ul class="workList">
                                                <li><a href="<?php echo$main_url;?>img/w1.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w2.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w3.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w4.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w5.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w6.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w7.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w8.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w9.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                <li><a href="<?php echo$main_url;?>img/w10.jpg" class="image-link"><i class="fa fa-search"></i></a><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                            </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-2">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-3">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="tab-content" id="tab-4">
                                            <div class="workGal">
                                                <ul class="workList">
                                                    <li><img src="<?php echo$main_url;?>img/w1.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w2.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w3.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w4.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w5.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w6.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w7.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w8.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w9.jpg" alt=""></li>
                                                    <li><img src="<?php echo$main_url;?>img/w10.jpg" alt=""></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-12">
                                            <ul class="list-center">
                                                <li><a href="#" class="btn btn-rounded btn-black btn-block btn-lg popupBox" data-toggle="modal" data-target="getQuote">lets get started</a></li>
                                                <li><a href="#" class="btn btn-rounded btn-white-outline active chat btn-lg">chat now</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="pg" data-aos="fade-down">
                                <div class="simplerSol">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="text-center">
                                                    <h2 class="title">Simpler Solutions. Quicker Results.</h2>
                                                    <p>Our Apps are designed in accordance to your industry trends</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="serviceSlider">
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Native React Apps</h3>
                                                        <p>
                                                            Confused between two leading platforms? Try a native react app. Native react apps work just as fluently on Swift and C-programming codes as with Java codes with a single database. For a better hold on both Android and Apple user market, go for a mixed approach. This is better for businesses who are trying to expand on both local and international levels.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Rapid, agile and trusted</li>
                                                            <li>VR/AR, IoT and E-commerce</li>
                                                            <li>UI/UX Friend</li>
                                                            <li>Safe & Secure</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/ss.jpg" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>iOS Applications</h3>
                                                        <p>
                                                        iOS applications require more expertise and security parameters to get approved on the Apple Store. We develop iOS apps for iPhones, iWearables and iPads using the Swift and Objective-C programming languages, following Apple’s own development tools and guidelines. Target the growing market of Apple users with our iOS Apps.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Rapid, agile and trusted</li>
                                                            <li>VR/AR, IoT and E-commerce</li>
                                                            <li>UI/UX Friend</li>
                                                            <li>Safe & Secure</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/IOS.png" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="ss-slider">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h3>Android Applications</h3>
                                                        <p>
                                                            Android is the best platform for brands with wider and
                                                            international audineces. The easier management and optimization features of Android apps makes them a fit
                                                            for all season and industries. Whether you need an app
                                                            for business or personal needs, Designs Aveneue has
                                                            it all covered under one roof.
                                                        </p>
                                                        <ul class="arrow-list">
                                                            <li>Rapid, agile and trusted</li>
                                                            <li>VR/AR, IoT and E-commerce</li>
                                                            <li>UI/UX Friend</li>
                                                            <li>Safe & Secure</li>
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <img src="<?php echo$main_url;?>img/AA.png" alt="ss">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    </div>
                    <div class="tab-pane" id="2a">
                            <div class="pg secretDelievery" data-aos="fade-down">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">Our Secret To Always Deliver Above Average</h2>
                                            <p>Lies in our flawless and efficient process, delivering 110% satisfaction!</p>
                                            <ul class="list-center">
                                                <li>
                                                    <i class="sprite_1 sprite-sQ"></i>
                                                    <h4>Fill out our simple questionnaire</h4>
                                                    <p>This helps our experts to analyze the requirements, and take your project in right direction.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-appD"></i>
                                                    <h4>App <br>Designing</h4>
                                                    <p>Our skilled designers get started on your project with a fully customized and UX/UI-friendly design.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-dR1"></i>
                                                    <h4>App <br>Development</h4>
                                                    <p>Our industry tested developers bring the visions of your perfect mobile app to life with safe & secure coding.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-aT"></i>
                                                    <h4>App <br>Testing</h4>
                                                    <p>We run our apps through multiple sessions of Q/A testing to catch any bugs or erros before the app goes live.</p>
                                                </li>
                                                <li>
                                                    <i class="sprite_1 sprite-pD"></i>
                                                    <h4>Project <br>Delivery</h4>
                                                    <p>Your app is all set and ready to go live. We help you in app store settings until it is running smoothly.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <div class="tab-pane" id="3a">
                            <div class="pg secretDelievery" data-aos="fade-up">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <h2 class="title">FAQS</h2>
                                            <p>
                                                For All Your General Queries, Go Through Our Detailed FAQS.
                                            </p>
                                            <ul class="arrow-list">
                                                <li>
                                                    <h4>Is mobile application important for my business?</h4>
                                                    <p>The number of mobile phone users is increasing each day. At this point, it is pretty clear that every business regardless of its nature should go mobile. Either for marketing, branding or management purposes.</p>
                                                </li>
                                                <li>
                                                    <h4>What is the total turnaround time of a mobile app?</h4>
                                                    <p>It takes our experts to go through the entire process of design/development all the way to Q/A sessions around 3 to 4 weeks.</p>
                                                </li>
                                                <li>
                                                    <h4>What type of mobile app should I get?</h4>
                                                    <p>To make sure you put your investments in the right place, read our sevices pages defining the use and benefits of each type in detail. For further assistance, contact us.</p>
                                                </li>
                                                <li>
                                                    <h4>What if I don't like my app?</h4>
                                                    <p>We make sure this never happens by giving free and unlimited revisions to our clients on earlier stages of mockups and wireframing. But in such a thing happens, go through our refund and money back guarantee section.
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>I don't like my current app.</h4>
                                                    <p>No problem! Logos Web Design can revamp your apps in no time.
                                                    </p>
                                                </li>
                                                <li>
                                                    <h4>How do I get started?</h4>
                                                    <p>Fill our contact form, chat live or call our consultants.</p>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
    <?php include("inc/numbers.php"); ?>
    <?php include("inc/contact-bar.php"); ?>
    <?php include("inc/testimonials.php"); ?>
    <?php include("inc/footer.php"); ?>
</html>   